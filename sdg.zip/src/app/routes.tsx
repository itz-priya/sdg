import { createBrowserRouter } from "react-router";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import BudgetWallet from "./pages/BudgetWallet";
import ProcurementRequest from "./pages/ProcurementRequest";
import AssetTracker from "./pages/AssetTracker";
import ApprovalCenter from "./pages/ApprovalCenter";
import Analytics from "./pages/Analytics";
import ReportGenerator from "./pages/ReportGenerator";
import AdminPanel from "./pages/AdminPanel";
import StudentEvents from "./pages/StudentEvents";
import CoordinatorDashboard from "./pages/CoordinatorDashboard";
import StaffCoordinatorPortal from "./pages/StaffCoordinatorPortal";
import Layout from "./components/Layout";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Login,
  },
  {
    path: "/",
    Component: Layout,
    children: [
      // Student Routes
      { path: "student/events", Component: StudentEvents },
      
      // Student Coordinator Routes
      { path: "coordinator/dashboard", Component: CoordinatorDashboard },
      
      // Staff Coordinator Routes
      { path: "staff/events", Component: StaffCoordinatorPortal },
      
      // HOD Routes
      { path: "hod/dashboard", Component: Dashboard },
      { path: "hod/budget", Component: BudgetWallet },
      { path: "hod/approvals", Component: ApprovalCenter },
      
      // Principal Routes
      { path: "principal/dashboard", Component: Analytics },
      { path: "principal/reports", Component: ReportGenerator },
      
      // Legacy routes (kept for backward compatibility)
      { path: "dashboard", Component: Dashboard },
      { path: "budget", Component: BudgetWallet },
      { path: "procurement", Component: ProcurementRequest },
      { path: "assets", Component: AssetTracker },
      { path: "approvals", Component: ApprovalCenter },
      { path: "analytics", Component: Analytics },
      { path: "reports", Component: ReportGenerator },
      { path: "admin", Component: AdminPanel },
    ],
  },
]);