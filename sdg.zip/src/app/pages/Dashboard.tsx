import { TrendingUp, TrendingDown, AlertTriangle, DollarSign, FileText, Package, Clock, ArrowRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Progress } from '../components/ui/progress';
import { Badge } from '../components/ui/badge';
import { useNavigate } from 'react-router';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const spendingData = [
  { month: 'Jul', amount: 45000 },
  { month: 'Aug', amount: 62000 },
  { month: 'Sep', amount: 48000 },
  { month: 'Oct', amount: 75000 },
  { month: 'Nov', amount: 58000 },
  { month: 'Dec', amount: 82000 },
];

const pendingActions = [
  { id: 'REQ-123', title: 'Projector - Faculty A', amount: 45000, type: 'Procurement', urgent: true },
  { id: 'REQ-124', title: 'Lab Chemicals Purchase', amount: 12000, type: 'Procurement', urgent: false },
  { id: 'APPR-045', title: 'Budget Reallocation', amount: 25000, type: 'Approval', urgent: true },
];

const recentActivity = [
  { action: 'Laptop Purchase Approved', time: '2 hours ago', status: 'success' },
  { action: 'Seminar Budget Pending', time: '5 hours ago', status: 'warning' },
  { action: 'Asset CST-001 Updated', time: '1 day ago', status: 'info' },
];

export default function Dashboard() {
  const navigate = useNavigate();

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-3xl font-bold text-[#0A1F44]">Role-Based Command Dashboard</h1>
        <p className="text-gray-600 mt-1">CSE Department - FY 2025-26</p>
      </div>

      {/* Top Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Budget Balance */}
        <Card className="border-l-4 border-l-[#0A1F44]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Budget Balance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-bold text-[#0A1F44]">₹4,72,500</span>
                <span className="text-sm text-gray-500">/ ₹5L</span>
              </div>
              <Progress value={94.5} className="h-2" />
              <p className="text-xs text-gray-600">Dept: CSE</p>
              <Button
                variant="link"
                size="sm"
                className="text-[#0A1F44] p-0 h-auto"
                onClick={() => navigate('/budget')}
              >
                View Breakdown <ArrowRight className="w-3 h-3 ml-1" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Pending Actions */}
        <Card className="border-l-4 border-l-orange-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Pending Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-2xl font-bold text-orange-600">5</span>
                <Clock className="w-8 h-8 text-orange-500" />
              </div>
              <div className="space-y-1 text-sm">
                <p className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-red-500 rounded-full"></span>
                  3 Procurement Requests
                </p>
                <p className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-yellow-500 rounded-full"></span>
                  2 Approvals Needed
                </p>
              </div>
              <Button
                variant="link"
                size="sm"
                className="text-orange-600 p-0 h-auto"
                onClick={() => navigate('/approvals')}
              >
                Review All <ArrowRight className="w-3 h-3 ml-1" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Quick Stats */}
        <Card className="border-l-4 border-l-[#90EE90]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Utilization Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-2xl font-bold text-[#90EE90]">78%</span>
                <TrendingUp className="w-8 h-8 text-[#90EE90]" />
              </div>
              <div className="space-y-1 text-sm">
                <p className="flex items-center justify-between">
                  <span>Committed:</span>
                  <span className="font-semibold">₹2.3L</span>
                </p>
                <p className="flex items-center justify-between">
                  <span>Spent:</span>
                  <span className="font-semibold">₹3.7L</span>
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Alerts */}
        <Card className="border-l-4 border-l-red-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Risk Alerts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-2xl font-bold text-red-600">2</span>
                <AlertTriangle className="w-8 h-8 text-red-500" />
              </div>
              <div className="space-y-1 text-sm">
                <p className="text-red-600 font-medium">Overspend Risk Detected</p>
                <p className="text-gray-600">MECH Dept - 92% utilized</p>
              </div>
              <Button
                variant="link"
                size="sm"
                className="text-red-600 p-0 h-auto"
                onClick={() => navigate('/analytics')}
              >
                View Analytics <ArrowRight className="w-3 h-3 ml-1" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Spending Trends Chart */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-[#0A1F44]" />
              Spending Trends - Last 6 Months
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={spendingData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(value) => `₹${value.toLocaleString()}`} />
                <Line 
                  type="monotone" 
                  dataKey="amount" 
                  stroke="#0A1F44" 
                  strokeWidth={3}
                  dot={{ fill: '#90EE90', r: 5 }}
                />
              </LineChart>
            </ResponsiveContainer>
            <div className="mt-4 flex items-center justify-between text-sm">
              <span className="text-gray-600">Average Monthly Spend</span>
              <span className="font-bold text-[#0A1F44]">₹61,667</span>
            </div>
          </CardContent>
        </Card>

        {/* Pending Actions List */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-[#0A1F44]" />
              Pending Actions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {pendingActions.map((action) => (
                <div
                  key={action.id}
                  className="p-3 border border-gray-200 rounded-lg hover:border-[#0A1F44] transition-colors cursor-pointer"
                  onClick={() => navigate('/approvals')}
                >
                  <div className="flex items-start justify-between mb-2">
                    <span className="text-xs font-mono text-gray-500">{action.id}</span>
                    {action.urgent && (
                      <Badge variant="destructive" className="text-xs">Urgent</Badge>
                    )}
                  </div>
                  <p className="font-medium text-sm mb-1">{action.title}</p>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">{action.type}</span>
                    <span className="font-bold text-[#0A1F44]">₹{action.amount.toLocaleString()}</span>
                  </div>
                </div>
              ))}
            </div>
            <Button 
              variant="outline" 
              className="w-full mt-4 border-[#0A1F44] text-[#0A1F44] hover:bg-[#0A1F44] hover:text-white"
              onClick={() => navigate('/approvals')}
            >
              View All Pending
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Quick Action Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card 
          className="cursor-pointer hover:shadow-lg transition-shadow border-t-4 border-t-[#0A1F44]"
          onClick={() => navigate('/assets')}
        >
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-[#0A1F44]/10 rounded-lg flex items-center justify-center">
                <Package className="w-6 h-6 text-[#0A1F44]" />
              </div>
              <div>
                <p className="text-2xl font-bold text-[#0A1F44]">127</p>
                <p className="text-sm text-gray-600">Active Assets</p>
              </div>
            </div>
            <Button variant="link" className="mt-4 p-0 h-auto text-[#0A1F44]">
              View Asset Register <ArrowRight className="w-3 h-3 ml-1" />
            </Button>
          </CardContent>
        </Card>

        <Card 
          className="cursor-pointer hover:shadow-lg transition-shadow border-t-4 border-t-[#90EE90]"
          onClick={() => navigate('/reports')}
        >
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-[#90EE90]/20 rounded-lg flex items-center justify-center">
                <FileText className="w-6 h-6 text-[#0A1F44]" />
              </div>
              <div>
                <p className="text-2xl font-bold text-[#0A1F44]">8</p>
                <p className="text-sm text-gray-600">Reports Ready</p>
              </div>
            </div>
            <Button variant="link" className="mt-4 p-0 h-auto text-[#0A1F44]">
              Generate Reports <ArrowRight className="w-3 h-3 ml-1" />
            </Button>
          </CardContent>
        </Card>

        <Card 
          className="cursor-pointer hover:shadow-lg transition-shadow border-t-4 border-t-orange-500"
          onClick={() => navigate('/procurement')}
        >
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-orange-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-[#0A1F44]">12</p>
                <p className="text-sm text-gray-600">Active Requests</p>
              </div>
            </div>
            <Button variant="link" className="mt-4 p-0 h-auto text-orange-600">
              New Request <ArrowRight className="w-3 h-3 ml-1" />
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-[#0A1F44]" />
            Recent Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {recentActivity.map((item, index) => (
              <div key={index} className="flex items-center justify-between py-2 border-b last:border-0">
                <div className="flex items-center gap-3">
                  <div className={`w-2 h-2 rounded-full ${
                    item.status === 'success' ? 'bg-green-500' :
                    item.status === 'warning' ? 'bg-yellow-500' : 'bg-blue-500'
                  }`}></div>
                  <span className="font-medium">{item.action}</span>
                </div>
                <span className="text-sm text-gray-500">{item.time}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
