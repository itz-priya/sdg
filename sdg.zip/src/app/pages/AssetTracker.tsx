import { useState } from 'react';
import { Package, MapPin, Wrench, TrendingDown, Edit, Trash2, Share2, QrCode, Calendar, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Badge } from '../components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Label } from '../components/ui/label';

const assets = [
  {
    id: 'CST-001',
    name: 'Dell Laptop i7',
    category: 'Computer',
    purchaseDate: '2026-01-15',
    amount: 25000,
    location: 'Lab-101',
    status: 'active',
    assignedTo: 'CSE Department',
    linkedBudget: 'REQ-456',
    condition: 'Excellent',
    warrantyExpiry: '2027-01-15',
    lastMaintenance: '2026-02-01',
    nextMaintenance: '2027-03-01',
    depreciationRate: 15,
    currentValue: 21250,
    serialNumber: 'DL789456123',
  },
  {
    id: 'CST-002',
    name: 'Dell Laptop i7',
    category: 'Computer',
    purchaseDate: '2026-01-15',
    amount: 25000,
    location: 'Lab-101',
    status: 'active',
    assignedTo: 'CSE Department',
    linkedBudget: 'REQ-456',
    condition: 'Good',
    warrantyExpiry: '2027-01-15',
    lastMaintenance: '2026-02-01',
    nextMaintenance: '2027-03-01',
    depreciationRate: 15,
    currentValue: 21250,
    serialNumber: 'DL789456124',
  },
  {
    id: 'CST-045',
    name: 'Epson Projector',
    category: 'Electronics',
    purchaseDate: '2025-08-20',
    amount: 45000,
    location: 'Seminar Hall',
    status: 'maintenance',
    assignedTo: 'CSE Department',
    linkedBudget: 'REQ-234',
    condition: 'Fair',
    warrantyExpiry: '2026-08-20',
    lastMaintenance: '2026-01-15',
    nextMaintenance: '2026-04-15',
    depreciationRate: 20,
    currentValue: 36000,
    serialNumber: 'EP456123789',
  },
  {
    id: 'CST-078',
    name: 'Network Router Cisco',
    category: 'Networking',
    purchaseDate: '2024-05-10',
    amount: 35000,
    location: 'Server Room',
    status: 'active',
    assignedTo: 'IT Department',
    linkedBudget: 'REQ-189',
    condition: 'Good',
    warrantyExpiry: '2027-05-10',
    lastMaintenance: '2025-11-10',
    nextMaintenance: '2026-05-10',
    depreciationRate: 10,
    currentValue: 31500,
    serialNumber: 'CS789654123',
  },
];

export default function AssetTracker() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAsset, setSelectedAsset] = useState(assets[0]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-700';
      case 'maintenance': return 'bg-yellow-100 text-yellow-700';
      case 'disposed': return 'bg-gray-100 text-gray-700';
      case 'lost': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getConditionColor = (condition: string) => {
    switch (condition) {
      case 'Excellent': return 'text-green-600';
      case 'Good': return 'text-blue-600';
      case 'Fair': return 'text-yellow-600';
      case 'Poor': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#0A1F44]">Asset Lifecycle Tracker</h1>
          <p className="text-gray-600 mt-1">Complete asset register with maintenance tracking</p>
        </div>
        <Button className="bg-[#0A1F44] hover:bg-[#1a3a5c]">
          <Package className="w-4 h-4 mr-2" />
          Add New Asset
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Assets</p>
                <p className="text-3xl font-bold text-[#0A1F44]">127</p>
              </div>
              <Package className="w-10 h-10 text-[#0A1F44]" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active</p>
                <p className="text-3xl font-bold text-green-600">112</p>
              </div>
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                <span className="text-2xl">✓</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Maintenance Due</p>
                <p className="text-3xl font-bold text-yellow-600">8</p>
              </div>
              <Wrench className="w-10 h-10 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Value</p>
                <p className="text-3xl font-bold text-[#0A1F44]">₹42.5L</p>
              </div>
              <TrendingDown className="w-10 h-10 text-[#0A1F44]" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Search */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <Input
                placeholder="Search by Asset ID, Name, or Serial Number..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="border-[#0A1F44]/20"
              />
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="md:w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="computer">Computers</SelectItem>
                <SelectItem value="electronics">Electronics</SelectItem>
                <SelectItem value="furniture">Furniture</SelectItem>
                <SelectItem value="networking">Networking</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline">
              <QrCode className="w-4 h-4 mr-2" />
              Scan QR
            </Button>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="register" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="register">Asset Register</TabsTrigger>
          <TabsTrigger value="maintenance">Maintenance</TabsTrigger>
          <TabsTrigger value="lifecycle">Lifecycle</TabsTrigger>
        </TabsList>

        {/* Asset Register */}
        <TabsContent value="register" className="space-y-4">
          {assets.map((asset) => (
            <Card key={asset.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Main Info */}
                  <div className="lg:col-span-2 space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-xl font-bold text-[#0A1F44]">{asset.name}</h3>
                          <Badge className={getStatusColor(asset.status)}>
                            {asset.status.toUpperCase()}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
                          <span className="font-mono bg-gray-100 px-2 py-1 rounded">{asset.id}</span>
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            {asset.location}
                          </span>
                          <span>Serial: {asset.serialNumber}</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-[#0A1F44]">₹{asset.amount.toLocaleString()}</p>
                        <p className="text-sm text-gray-600">Purchase Price</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <p className="text-gray-600">Category</p>
                        <p className="font-semibold">{asset.category}</p>
                      </div>
                      <div>
                        <p className="text-gray-600">Assigned To</p>
                        <p className="font-semibold">{asset.assignedTo}</p>
                      </div>
                      <div>
                        <p className="text-gray-600">Condition</p>
                        <p className={`font-semibold ${getConditionColor(asset.condition)}`}>{asset.condition}</p>
                      </div>
                      <div>
                        <p className="text-gray-600">Current Value</p>
                        <p className="font-semibold">₹{asset.currentValue.toLocaleString()}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 p-3 bg-[#90EE90]/10 border border-[#90EE90] rounded-lg text-sm">
                      <span className="text-gray-600">Linked Budget:</span>
                      <span className="font-mono font-semibold text-[#0A1F44]">{asset.linkedBudget}</span>
                      <span className="text-[#90EE90]">→ ASSET LINKED ✓</span>
                    </div>
                  </div>

                  {/* Actions and Dates */}
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Purchase Date</span>
                        <span className="font-semibold">{new Date(asset.purchaseDate).toLocaleDateString('en-IN')}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Warranty Expiry</span>
                        <span className="font-semibold">{new Date(asset.warrantyExpiry).toLocaleDateString('en-IN')}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Last Maintenance</span>
                        <span className="font-semibold">{new Date(asset.lastMaintenance).toLocaleDateString('en-IN')}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Next Due</span>
                        <span className="font-semibold text-orange-600">{new Date(asset.nextMaintenance).toLocaleDateString('en-IN')}</span>
                      </div>
                    </div>

                    <div className="flex flex-col gap-2">
                      <Button variant="outline" size="sm" className="w-full">
                        <Edit className="w-4 h-4 mr-2" />
                        Edit Details
                      </Button>
                      <Button variant="outline" size="sm" className="w-full">
                        <Share2 className="w-4 h-4 mr-2" />
                        Transfer Asset
                      </Button>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm" className="w-full">
                            <Wrench className="w-4 h-4 mr-2" />
                            Schedule Service
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Schedule Maintenance</DialogTitle>
                          </DialogHeader>
                          <form className="space-y-4">
                            <div className="space-y-2">
                              <Label>Asset ID</Label>
                              <Input value={asset.id} disabled />
                            </div>
                            <div className="space-y-2">
                              <Label>Maintenance Date</Label>
                              <Input type="date" />
                            </div>
                            <div className="space-y-2">
                              <Label>Service Type</Label>
                              <Select>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select type" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="routine">Routine Check</SelectItem>
                                  <SelectItem value="repair">Repair</SelectItem>
                                  <SelectItem value="upgrade">Upgrade</SelectItem>
                                  <SelectItem value="cleaning">Cleaning</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <Button type="submit" className="w-full bg-[#0A1F44]">Schedule</Button>
                          </form>
                        </DialogContent>
                      </Dialog>
                      <Button variant="destructive" size="sm" className="w-full">
                        <Trash2 className="w-4 h-4 mr-2" />
                        Mark for Disposal
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        {/* Maintenance Tab */}
        <TabsContent value="maintenance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Wrench className="w-5 h-5 text-[#0A1F44]" />
                Upcoming Maintenance Schedule
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {assets.filter(a => a.status === 'maintenance' || new Date(a.nextMaintenance) < new Date(Date.now() + 90 * 24 * 60 * 60 * 1000)).map((asset) => (
                  <div key={asset.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-center gap-4">
                      <AlertCircle className="w-5 h-5 text-orange-500" />
                      <div>
                        <p className="font-semibold">{asset.name}</p>
                        <p className="text-sm text-gray-600">{asset.id} - {asset.location}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-600">Next Service</p>
                      <p className="font-semibold">{new Date(asset.nextMaintenance).toLocaleDateString('en-IN')}</p>
                    </div>
                    <Button size="sm" variant="outline">
                      Schedule Now
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Maintenance History */}
          <Card>
            <CardHeader>
              <CardTitle>Maintenance History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <div className="flex items-center justify-between py-2 border-b">
                  <span>CST-001 - Routine Check</span>
                  <span className="text-gray-600">2026-02-01</span>
                  <Badge className="bg-green-100 text-green-700">Completed</Badge>
                </div>
                <div className="flex items-center justify-between py-2 border-b">
                  <span>CST-045 - Lamp Replacement</span>
                  <span className="text-gray-600">2026-01-15</span>
                  <Badge className="bg-green-100 text-green-700">Completed</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Lifecycle Tab */}
        <TabsContent value="lifecycle" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-[#0A1F44]" />
                Asset Lifecycle Stages
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Lifecycle Flow */}
                <div className="flex items-center justify-between">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-[#0A1F44] text-white rounded-full flex items-center justify-center mx-auto mb-2">
                      <Package className="w-8 h-8" />
                    </div>
                    <p className="font-semibold text-sm">Acquisition</p>
                    <p className="text-xs text-gray-600">From Procurement</p>
                  </div>
                  <div className="w-12 h-0.5 bg-gray-300"></div>
                  <div className="text-center">
                    <div className="w-16 h-16 bg-[#90EE90] text-[#0A1F44] rounded-full flex items-center justify-center mx-auto mb-2">
                      <MapPin className="w-8 h-8" />
                    </div>
                    <p className="font-semibold text-sm">Allocation</p>
                    <p className="text-xs text-gray-600">Dept Assignment</p>
                  </div>
                  <div className="w-12 h-0.5 bg-gray-300"></div>
                  <div className="text-center">
                    <div className="w-16 h-16 bg-blue-500 text-white rounded-full flex items-center justify-center mx-auto mb-2">
                      <Wrench className="w-8 h-8" />
                    </div>
                    <p className="font-semibold text-sm">Maintenance</p>
                    <p className="text-xs text-gray-600">Regular Service</p>
                  </div>
                  <div className="w-12 h-0.5 bg-gray-300"></div>
                  <div className="text-center">
                    <div className="w-16 h-16 bg-orange-500 text-white rounded-full flex items-center justify-center mx-auto mb-2">
                      <TrendingDown className="w-8 h-8" />
                    </div>
                    <p className="font-semibold text-sm">Depreciation</p>
                    <p className="text-xs text-gray-600">Value Decrease</p>
                  </div>
                  <div className="w-12 h-0.5 bg-gray-300"></div>
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gray-500 text-white rounded-full flex items-center justify-center mx-auto mb-2">
                      <Trash2 className="w-8 h-8" />
                    </div>
                    <p className="font-semibold text-sm">Disposal</p>
                    <p className="text-xs text-gray-600">End of Life</p>
                  </div>
                </div>

                {/* Depreciation Table */}
                <div className="pt-4 border-t">
                  <h4 className="font-semibold mb-3">Depreciation Schedule</h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="text-left p-2">Asset ID</th>
                          <th className="text-left p-2">Purchase Value</th>
                          <th className="text-left p-2">Current Value</th>
                          <th className="text-left p-2">Depreciation %</th>
                          <th className="text-left p-2">Age</th>
                        </tr>
                      </thead>
                      <tbody>
                        {assets.slice(0, 3).map((asset) => (
                          <tr key={asset.id} className="border-b">
                            <td className="p-2 font-mono">{asset.id}</td>
                            <td className="p-2">₹{asset.amount.toLocaleString()}</td>
                            <td className="p-2 font-semibold">₹{asset.currentValue.toLocaleString()}</td>
                            <td className="p-2 text-orange-600">{asset.depreciationRate}%</td>
                            <td className="p-2">{Math.floor((Date.now() - new Date(asset.purchaseDate).getTime()) / (365 * 24 * 60 * 60 * 1000))} years</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
