import { useState } from 'react';
import { Calendar, Package, ShoppingCart, Users, Plus, Trash2, Download, FileText } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';

const events = [
  {
    id: 'EVT-001',
    name: 'TechFest 2026',
    date: '2026-03-15',
    venue: 'Main Auditorium',
    studentCoordinator: 'Rahul Kumar',
    status: 'active',
    budget: 150000,
    department: 'CSE',
  },
  {
    id: 'EVT-003',
    name: 'Workshop: AI & ML',
    date: '2026-03-08',
    venue: 'Lab 301',
    studentCoordinator: 'Priya Sharma',
    status: 'active',
    budget: 25000,
    department: 'CSE',
  },
  {
    id: 'EVT-006',
    name: 'Project Expo',
    date: '2026-04-10',
    venue: 'Exhibition Hall',
    studentCoordinator: 'Ankit Verma',
    status: 'planning',
    budget: 75000,
    department: 'All',
  },
];

const studentCoordinators = [
  { id: 1, name: 'Rahul Kumar', regNo: '2021CSE045', department: 'CSE', email: 'rahul@student.cit.edu', events: ['EVT-001'], status: 'active' },
  { id: 2, name: 'Priya Sharma', regNo: '2021CSE062', department: 'CSE', email: 'priya@student.cit.edu', events: ['EVT-003'], status: 'active' },
  { id: 3, name: 'Ankit Verma', regNo: '2021CSE089', department: 'CSE', email: 'ankit@student.cit.edu', events: ['EVT-006'], status: 'active' },
  { id: 4, name: 'Sneha Patel', regNo: '2022CSE012', department: 'CSE', email: 'sneha@student.cit.edu', events: [], status: 'inactive' },
];

const procurementItems = [
  { id: 1, item: 'Printing Materials', event: 'TechFest 2026', quantity: 1, amount: 12000, status: 'approved', vendor: 'PrintHub' },
  { id: 2, item: 'Catering Services', event: 'TechFest 2026', quantity: 500, amount: 45000, status: 'pending', vendor: 'Tasty Bites' },
  { id: 3, item: 'Sound System Rental', event: 'Workshop: AI & ML', quantity: 1, amount: 8000, status: 'approved', vendor: 'AudioPro' },
  { id: 4, name: 'Projector Rental', event: 'Project Expo', quantity: 3, amount: 15000, status: 'pending', vendor: 'TechRent' },
];

const assetTracking = [
  { id: 1, event: 'TechFest 2026', asset: 'Chairs', required: 500, allocated: 500, returned: 0, condition: 'Good' },
  { id: 2, event: 'TechFest 2026', asset: 'Tables', required: 50, allocated: 50, returned: 0, condition: 'Good' },
  { id: 3, event: 'TechFest 2026', asset: 'Projectors', required: 3, allocated: 2, returned: 0, condition: 'Pending' },
  { id: 4, event: 'Workshop: AI & ML', asset: 'Lab Computers', required: 30, allocated: 30, returned: 0, condition: 'Good' },
  { id: 5, event: 'Workshop: AI & ML', asset: 'Screens', required: 2, allocated: 2, returned: 0, condition: 'Good' },
];

export default function StaffCoordinatorPortal() {
  const [showAddCoordinator, setShowAddCoordinator] = useState(false);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-3xl font-bold text-[#0A1F44]">Staff Coordinator Portal</h1>
        <p className="text-gray-600 mt-1">Oversee events, manage coordinators, and track assets</p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-l-4 border-l-[#0A1F44]">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Events</p>
                <p className="text-3xl font-bold text-[#0A1F44]">{events.length}</p>
              </div>
              <Calendar className="w-10 h-10 text-[#0A1F44]" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Coordinators</p>
                <p className="text-3xl font-bold text-green-600">
                  {studentCoordinators.filter(c => c.status === 'active').length}
                </p>
              </div>
              <Users className="w-10 h-10 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pending Approvals</p>
                <p className="text-3xl font-bold text-blue-600">
                  {procurementItems.filter(p => p.status === 'pending').length}
                </p>
              </div>
              <ShoppingCart className="w-10 h-10 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-orange-500">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Assets in Use</p>
                <p className="text-3xl font-bold text-orange-600">{assetTracking.length}</p>
              </div>
              <Package className="w-10 h-10 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="events" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="events">Event List</TabsTrigger>
          <TabsTrigger value="coordinators">Coordinators</TabsTrigger>
          <TabsTrigger value="assets">Asset Tracking</TabsTrigger>
          <TabsTrigger value="procurement">Procurement</TabsTrigger>
        </TabsList>

        {/* EVENTS TAB */}
        <TabsContent value="events" className="space-y-4">
          {events.map((event) => (
            <Card key={event.id} className="border-l-4 border-l-[#0A1F44]">
              <CardContent className="pt-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-xl font-bold text-[#0A1F44]">{event.name}</h3>
                      <Badge className={event.status === 'active' ? 'bg-green-500' : 'bg-yellow-500'}>
                        {event.status}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-gray-600">
                      <span className="font-mono">{event.id}</span>
                      <span>•</span>
                      <span>{new Date(event.date).toLocaleDateString('en-IN')}</span>
                      <span>•</span>
                      <span>{event.venue}</span>
                      <span>•</span>
                      <span>Budget: ₹{event.budget.toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <p className="text-sm text-gray-600">Student Coordinator</p>
                    <p className="font-semibold">{event.studentCoordinator}</p>
                    <p className="text-sm text-gray-600">Department: {event.department}</p>
                  </div>

                  <div className="flex flex-col gap-2">
                    <Button variant="outline" size="sm">
                      <Calendar className="w-4 h-4 mr-2" />
                      View Details
                    </Button>
                    <Button variant="outline" size="sm">
                      <Package className="w-4 h-4 mr-2" />
                      Track Assets
                    </Button>
                    <Button variant="outline" size="sm">
                      <Download className="w-4 h-4 mr-2" />
                      Generate Report (PDF)
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        {/* COORDINATORS TAB */}
        <TabsContent value="coordinators" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-[#0A1F44]" />
                  Student Coordinators Management
                </CardTitle>
                <Dialog open={showAddCoordinator} onOpenChange={setShowAddCoordinator}>
                  <DialogTrigger asChild>
                    <Button className="bg-[#0A1F44] hover:bg-[#1a3a5c]">
                      <Plus className="w-4 h-4 mr-2" />
                      Add Coordinator
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Student Coordinator</DialogTitle>
                    </DialogHeader>
                    <form className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="studentName">Student Name</Label>
                        <Input id="studentName" placeholder="Enter student name" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="regNo">Register Number</Label>
                        <Input id="regNo" placeholder="e.g., 2021CSE001" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="department">Department</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Select department" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="cse">CSE</SelectItem>
                            <SelectItem value="ece">ECE</SelectItem>
                            <SelectItem value="mech">MECH</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="assignEvent">Assign to Event</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Select event" />
                          </SelectTrigger>
                          <SelectContent>
                            {events.map(event => (
                              <SelectItem key={event.id} value={event.id}>
                                {event.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="flex gap-2">
                        <Button type="submit" className="flex-1 bg-[#0A1F44]">
                          Add Coordinator
                        </Button>
                        <Button 
                          type="button" 
                          variant="outline"
                          onClick={() => setShowAddCoordinator(false)}
                        >
                          Cancel
                        </Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="text-left p-3">Name</th>
                      <th className="text-left p-3">Register No</th>
                      <th className="text-left p-3">Department</th>
                      <th className="text-left p-3">Events Assigned</th>
                      <th className="text-center p-3">Status</th>
                      <th className="text-center p-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {studentCoordinators.map((coordinator) => (
                      <tr key={coordinator.id} className="border-b hover:bg-gray-50">
                        <td className="p-3 font-semibold">{coordinator.name}</td>
                        <td className="p-3 font-mono text-sm">{coordinator.regNo}</td>
                        <td className="p-3">{coordinator.department}</td>
                        <td className="p-3">
                          {coordinator.events.length > 0 ? (
                            <div className="flex flex-wrap gap-1">
                              {coordinator.events.map(eventId => (
                                <Badge key={eventId} variant="outline" className="text-xs">
                                  {eventId}
                                </Badge>
                              ))}
                            </div>
                          ) : (
                            <span className="text-gray-400 text-xs">No events</span>
                          )}
                        </td>
                        <td className="p-3 text-center">
                          <Badge 
                            className={
                              coordinator.status === 'active'
                                ? 'bg-green-100 text-green-700'
                                : 'bg-gray-100 text-gray-700'
                            }
                          >
                            {coordinator.status}
                          </Badge>
                        </td>
                        <td className="p-3">
                          <div className="flex gap-2 justify-center">
                            <Button variant="outline" size="sm">
                              Edit
                            </Button>
                            <Button variant="outline" size="sm" className="text-red-600">
                              <Trash2 className="w-3 h-3 mr-1" />
                              Revoke
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ASSET TRACKING TAB */}
        <TabsContent value="assets" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="w-5 h-5 text-[#0A1F44]" />
                Asset Lifecycle Tracking
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="text-left p-3">Event</th>
                      <th className="text-left p-3">Asset</th>
                      <th className="text-center p-3">Required</th>
                      <th className="text-center p-3">Allocated</th>
                      <th className="text-center p-3">Returned</th>
                      <th className="text-center p-3">Condition</th>
                      <th className="text-center p-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {assetTracking.map((item) => (
                      <tr key={item.id} className="border-b hover:bg-gray-50">
                        <td className="p-3 font-semibold">{item.event}</td>
                        <td className="p-3">{item.asset}</td>
                        <td className="p-3 text-center">{item.required}</td>
                        <td className="p-3 text-center font-bold">{item.allocated}</td>
                        <td className="p-3 text-center">{item.returned}</td>
                        <td className="p-3 text-center">
                          <Badge 
                            className={
                              item.condition === 'Good'
                                ? 'bg-green-100 text-green-700'
                                : item.condition === 'Pending'
                                ? 'bg-yellow-100 text-yellow-700'
                                : 'bg-red-100 text-red-700'
                            }
                          >
                            {item.condition}
                          </Badge>
                        </td>
                        <td className="p-3 text-center">
                          <Button variant="outline" size="sm">
                            Update
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* PROCUREMENT TAB */}
        <TabsContent value="procurement" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-[#0A1F44]" />
                Procurement Management
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {procurementItems.map((item) => (
                  <div 
                    key={item.id}
                    className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:border-[#0A1F44] transition-colors"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <p className="font-semibold">{item.item}</p>
                        <Badge 
                          className={
                            item.status === 'approved'
                              ? 'bg-green-100 text-green-700'
                              : 'bg-yellow-100 text-yellow-700'
                          }
                        >
                          {item.status}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <span>Event: {item.event}</span>
                        <span>•</span>
                        <span>Qty: {item.quantity}</span>
                        <span>•</span>
                        <span>Vendor: {item.vendor}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xl font-bold text-[#0A1F44]">₹{item.amount.toLocaleString()}</p>
                      {item.status === 'pending' && (
                        <div className="flex gap-2 mt-2">
                          <Button size="sm" className="bg-green-600">Approve</Button>
                          <Button size="sm" variant="outline">Reject</Button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Reports Section */}
      <Card className="border-t-4 border-t-[#90EE90]">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-[#0A1F44]" />
            Generate Reports (PDF)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button variant="outline" className="h-24 flex flex-col gap-2">
              <Calendar className="w-8 h-8" />
              <span>All Events Report</span>
            </Button>
            <Button variant="outline" className="h-24 flex flex-col gap-2">
              <Users className="w-8 h-8" />
              <span>Coordinators Report</span>
            </Button>
            <Button variant="outline" className="h-24 flex flex-col gap-2">
              <Package className="w-8 h-8" />
              <span>Asset Utilization Report</span>
            </Button>
            <Button variant="outline" className="h-24 flex flex-col gap-2">
              <ShoppingCart className="w-8 h-8" />
              <span>Procurement Summary</span>
            </Button>
            <Button variant="outline" className="h-24 flex flex-col gap-2">
              <FileText className="w-8 h-8" />
              <span>Financial Overview</span>
            </Button>
            <Button variant="outline" className="h-24 flex flex-col gap-2">
              <Download className="w-8 h-8" />
              <span>Complete Report</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
