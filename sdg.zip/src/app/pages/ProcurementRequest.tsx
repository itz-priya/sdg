import { useState } from 'react';
import { ShoppingCart, Upload, Send, Save, Clock, CheckCircle, XCircle, ArrowRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Textarea } from '../components/ui/textarea';
import { Badge } from '../components/ui/badge';
import { Progress } from '../components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';

const existingRequests = [
  {
    id: 'REQ-456',
    item: 'Dell Laptops i7',
    quantity: 5,
    vendor: 'Dell India',
    amount: 125000,
    status: 'approved',
    stage: 'Payment Processing',
    progress: 85,
    justification: 'Lab upgrade for AI/ML course',
    budgetHead: 'Equipment',
    requestedBy: 'Dr. John Doe',
    requestedOn: '2026-01-10',
    approvals: {
      hod: { status: 'approved', date: '2026-01-11', name: 'Dr. Sarah Smith' },
      finance: { status: 'approved', date: '2026-01-12', name: 'Mr. Kumar' },
      principal: { status: 'approved', date: '2026-01-13', name: 'Dr. Principal' },
    },
  },
  {
    id: 'REQ-457',
    item: 'Projector - Epson EB-2250U',
    quantity: 1,
    vendor: 'Epson Authorized',
    amount: 45000,
    status: 'pending',
    stage: 'HOD Approval',
    progress: 25,
    justification: 'Seminar hall equipment',
    budgetHead: 'Equipment',
    requestedBy: 'Faculty A',
    requestedOn: '2026-02-25',
    daysRemaining: 2,
  },
  {
    id: 'REQ-458',
    item: 'Lab Chemicals',
    quantity: 1,
    vendor: 'ChemSupply Co',
    amount: 12000,
    status: 'draft',
    stage: 'Draft',
    progress: 0,
    justification: 'Chemistry lab restocking',
    budgetHead: 'Consumables',
    requestedBy: 'Student Request',
    requestedOn: '2026-02-28',
  },
];

export default function ProcurementRequest() {
  const [activeTab, setActiveTab] = useState('new');
  const [formData, setFormData] = useState({
    item: '',
    quantity: '',
    vendor: '',
    amount: '',
    justification: '',
    budgetHead: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Procurement request submitted!');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-100 text-green-700 border-green-200';
      case 'pending': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'draft': return 'bg-gray-100 text-gray-700 border-gray-200';
      case 'rejected': return 'bg-red-100 text-red-700 border-red-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-3xl font-bold text-[#0A1F44]">Procurement Request Workflow</h1>
        <p className="text-gray-600 mt-1">Create and track procurement requests</p>
      </div>

      {/* Workflow Stages */}
      <Card className="border-t-4 border-t-[#0A1F44]">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-[#0A1F44] text-white rounded-full flex items-center justify-center font-bold">1</div>
              <div>
                <p className="font-semibold">Draft</p>
                <p className="text-xs text-gray-600">Create Request</p>
              </div>
            </div>
            <ArrowRight className="w-5 h-5 text-gray-400" />
            
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gray-200 text-gray-600 rounded-full flex items-center justify-center font-bold">2</div>
              <div>
                <p className="font-semibold">HOD</p>
                <p className="text-xs text-gray-600">Department Head</p>
              </div>
            </div>
            <ArrowRight className="w-5 h-5 text-gray-400" />
            
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gray-200 text-gray-600 rounded-full flex items-center justify-center font-bold">3</div>
              <div>
                <p className="font-semibold">Finance</p>
                <p className="text-xs text-gray-600">Budget Check</p>
              </div>
            </div>
            <ArrowRight className="w-5 h-5 text-gray-400" />
            
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gray-200 text-gray-600 rounded-full flex items-center justify-center font-bold">4</div>
              <div>
                <p className="font-semibold">Principal</p>
                <p className="text-xs text-gray-600">Final Approval</p>
              </div>
            </div>
            <ArrowRight className="w-5 h-5 text-gray-400" />
            
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-[#90EE90] text-[#0A1F44] rounded-full flex items-center justify-center">
                <CheckCircle className="w-5 h-5" />
              </div>
              <div>
                <p className="font-semibold">Approved</p>
                <p className="text-xs text-gray-600">Asset Induction</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="new">New Request</TabsTrigger>
          <TabsTrigger value="track">Track Requests</TabsTrigger>
        </TabsList>

        {/* New Request Form */}
        <TabsContent value="new" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-[#0A1F44]" />
                Create New Procurement Request
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Item Name */}
                  <div className="space-y-2">
                    <Label htmlFor="item" className="text-[#0A1F44] font-semibold">
                      Item / Description *
                    </Label>
                    <Input
                      id="item"
                      value={formData.item}
                      onChange={(e) => setFormData({ ...formData, item: e.target.value })}
                      placeholder="e.g., Dell Laptop i7 11th Gen"
                      required
                      className="border-[#0A1F44]/20 focus:border-[#90EE90]"
                    />
                  </div>

                  {/* Quantity */}
                  <div className="space-y-2">
                    <Label htmlFor="quantity" className="text-[#0A1F44] font-semibold">
                      Quantity *
                    </Label>
                    <Input
                      id="quantity"
                      type="number"
                      value={formData.quantity}
                      onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                      placeholder="0"
                      min="1"
                      required
                      className="border-[#0A1F44]/20 focus:border-[#90EE90]"
                    />
                  </div>

                  {/* Vendor */}
                  <div className="space-y-2">
                    <Label htmlFor="vendor" className="text-[#0A1F44] font-semibold">
                      Vendor / Supplier *
                    </Label>
                    <Input
                      id="vendor"
                      value={formData.vendor}
                      onChange={(e) => setFormData({ ...formData, vendor: e.target.value })}
                      placeholder="e.g., XYZ Technologies"
                      required
                      className="border-[#0A1F44]/20 focus:border-[#90EE90]"
                    />
                  </div>

                  {/* Amount */}
                  <div className="space-y-2">
                    <Label htmlFor="amount" className="text-[#0A1F44] font-semibold">
                      Total Amount (₹) *
                    </Label>
                    <Input
                      id="amount"
                      type="number"
                      value={formData.amount}
                      onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                      placeholder="0"
                      min="1"
                      required
                      className="border-[#0A1F44]/20 focus:border-[#90EE90]"
                    />
                  </div>

                  {/* Budget Head */}
                  <div className="space-y-2">
                    <Label htmlFor="budgetHead" className="text-[#0A1F44] font-semibold">
                      Budget Head *
                    </Label>
                    <Select value={formData.budgetHead} onValueChange={(value) => setFormData({ ...formData, budgetHead: value })}>
                      <SelectTrigger className="border-[#0A1F44]/20 focus:border-[#90EE90]">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="equipment">Equipment</SelectItem>
                        <SelectItem value="consumables">Consumables</SelectItem>
                        <SelectItem value="software">Software</SelectItem>
                        <SelectItem value="events">Events</SelectItem>
                        <SelectItem value="travel">Travel</SelectItem>
                        <SelectItem value="infrastructure">Infrastructure</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* File Upload */}
                  <div className="space-y-2">
                    <Label htmlFor="quote" className="text-[#0A1F44] font-semibold">
                      Attach Quote / Invoice
                    </Label>
                    <div className="flex items-center gap-2">
                      <Input
                        id="quote"
                        type="file"
                        className="border-[#0A1F44]/20 focus:border-[#90EE90]"
                        accept=".pdf,.jpg,.jpeg,.png"
                      />
                      <Button type="button" variant="outline" size="sm">
                        <Upload className="w-4 h-4" />
                      </Button>
                    </div>
                    <p className="text-xs text-gray-500">PDF, JPG, PNG (Max 5MB)</p>
                  </div>
                </div>

                {/* Justification */}
                <div className="space-y-2">
                  <Label htmlFor="justification" className="text-[#0A1F44] font-semibold">
                    Justification / Purpose *
                  </Label>
                  <Textarea
                    id="justification"
                    value={formData.justification}
                    onChange={(e) => setFormData({ ...formData, justification: e.target.value })}
                    placeholder="Explain why this procurement is necessary..."
                    rows={4}
                    required
                    className="border-[#0A1F44]/20 focus:border-[#90EE90]"
                  />
                </div>

                {/* Budget Allocation Preview */}
                {formData.amount && (
                  <div className="p-4 bg-[#90EE90]/10 border border-[#90EE90] rounded-lg">
                    <h4 className="font-semibold text-[#0A1F44] mb-2">Budget Allocation Preview</h4>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="text-gray-600">Available Budget</p>
                        <p className="font-bold text-[#0A1F44]">₹27,500</p>
                      </div>
                      <div>
                        <p className="text-gray-600">Request Amount</p>
                        <p className="font-bold text-orange-600">₹{Number(formData.amount).toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-gray-600">Balance After</p>
                        <p className={`font-bold ${27500 - Number(formData.amount) < 0 ? 'text-red-600' : 'text-green-600'}`}>
                          ₹{(27500 - Number(formData.amount)).toLocaleString()}
                        </p>
                      </div>
                    </div>
                    {27500 - Number(formData.amount) < 0 && (
                      <p className="text-red-600 text-sm mt-2 flex items-center gap-2">
                        <XCircle className="w-4 h-4" />
                        Insufficient budget! Requires HOD approval for reallocation.
                      </p>
                    )}
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex gap-3">
                  <Button type="submit" className="bg-[#0A1F44] hover:bg-[#1a3a5c]">
                    <Send className="w-4 h-4 mr-2" />
                    Submit Request
                  </Button>
                  <Button type="button" variant="outline">
                    <Save className="w-4 h-4 mr-2" />
                    Save as Draft
                  </Button>
                  <Button type="button" variant="ghost">
                    Clear Form
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Track Requests */}
        <TabsContent value="track" className="space-y-4">
          {existingRequests.map((req) => (
            <Card key={req.id} className="border-l-4 border-l-[#0A1F44]">
              <CardContent className="pt-6">
                <div className="space-y-4">
                  {/* Header */}
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-xl font-bold text-[#0A1F44]">{req.item}</h3>
                        <Badge className={getStatusColor(req.status)}>
                          {req.status.toUpperCase()}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <span className="font-mono">{req.id}</span>
                        <span>•</span>
                        <span>Qty: {req.quantity}</span>
                        <span>•</span>
                        <span>Vendor: {req.vendor}</span>
                        <span>•</span>
                        <span>{req.requestedOn}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-[#0A1F44]">₹{req.amount.toLocaleString()}</p>
                      <p className="text-sm text-gray-600">{req.budgetHead}</p>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-medium text-[#0A1F44]">Status: {req.stage}</span>
                      {req.daysRemaining && (
                        <span className="flex items-center gap-1 text-orange-600">
                          <Clock className="w-4 h-4" />
                          {req.daysRemaining} days remaining
                        </span>
                      )}
                    </div>
                    <Progress value={req.progress} className="h-2" />
                  </div>

                  {/* Details */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600 mb-1">Justification</p>
                      <p className="font-medium">{req.justification}</p>
                    </div>
                    <div>
                      <p className="text-gray-600 mb-1">Requested By</p>
                      <p className="font-medium">{req.requestedBy}</p>
                    </div>
                  </div>

                  {/* Approval Chain */}
                  {req.approvals && (
                    <div className="pt-4 border-t">
                      <p className="text-sm font-semibold text-[#0A1F44] mb-3">Approval Chain</p>
                      <div className="flex items-center gap-2">
                        {Object.entries(req.approvals).map(([role, data], index) => (
                          <div key={role} className="flex items-center gap-2">
                            <div className="flex items-center gap-2 px-3 py-2 bg-green-50 border border-green-200 rounded-lg">
                              <CheckCircle className="w-4 h-4 text-green-600" />
                              <div className="text-xs">
                                <p className="font-semibold text-green-800">{role.toUpperCase()}</p>
                                <p className="text-green-600">{data.name}</p>
                                <p className="text-gray-500">{data.date}</p>
                              </div>
                            </div>
                            {index < Object.entries(req.approvals).length - 1 && (
                              <ArrowRight className="w-4 h-4 text-gray-400" />
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}
