import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Lock, Mail, User, Shield, Eye, EyeOff, Phone, Hash, Calendar, Building } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Card } from '../components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import logoImage from 'figma:asset/019fea43cd48134f3e507bb71f3a1e982f09571c.png';

export default function Login() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('signin');
  
  // Sign In State
  const [signInRole, setSignInRole] = useState('student');
  const [signInEmail, setSignInEmail] = useState('');
  const [signInPassword, setSignInPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Sign Up State - Student
  const [studentName, setStudentName] = useState('');
  const [studentEmail, setStudentEmail] = useState('');
  const [studentRegNo, setStudentRegNo] = useState('');
  const [studentDept, setStudentDept] = useState('');
  const [studentPhone, setStudentPhone] = useState('');
  const [studentPassword, setStudentPassword] = useState('');
  const [studentBatch, setStudentBatch] = useState('');

  // Sign Up State - Staff/Admin
  const [staffName, setStaffName] = useState('');
  const [staffEmail, setStaffEmail] = useState('');
  const [staffDept, setStaffDept] = useState('');
  const [staffPhone, setStaffPhone] = useState('');
  const [staffPassword, setStaffPassword] = useState('');
  const [staffRole, setStaffRole] = useState('faculty');

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    // Navigate to role-specific dashboard
    if (signInRole === 'student') {
      navigate('/student/events');
    } else if (signInRole === 'student_coordinator') {
      navigate('/coordinator/dashboard');
    } else if (signInRole === 'faculty' || signInRole === 'staff_coordinator') {
      navigate('/staff/events');
    } else if (signInRole === 'hod') {
      navigate('/hod/dashboard');
    } else if (signInRole === 'principal') {
      navigate('/principal/dashboard');
    } else if (signInRole === 'admin') {
      navigate('/admin');
    }
  };

  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Sign up successful! Please sign in.');
    setActiveTab('signin');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A1F44] via-[#1a3a5c] to-[#0A1F44] flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl bg-white/95 backdrop-blur-sm shadow-2xl border-0">
        <div className="p-8">
          {/* Logo and Header */}
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <img src={logoImage} alt="Chennai Institute of Technology" className="h-16 object-contain" />
            </div>
            <div className="flex items-center justify-center gap-2 mb-2">
              <Shield className="w-6 h-6 text-[#0A1F44]" />
              <h1 className="text-2xl font-bold text-[#0A1F44]">CAMPUSFIN PORTAL</h1>
            </div>
            <p className="text-sm text-gray-600 font-medium">Event & Financial Management System</p>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="signin">Sign In</TabsTrigger>
              <TabsTrigger value="signup">Sign Up</TabsTrigger>
            </TabsList>

            {/* SIGN IN TAB */}
            <TabsContent value="signin">
              <form onSubmit={handleSignIn} className="space-y-5">
                {/* Role Selection */}
                <div className="space-y-2">
                  <Label htmlFor="role" className="text-[#0A1F44] font-semibold flex items-center gap-2">
                    <User className="w-4 h-4" />
                    Select Role
                  </Label>
                  <Select value={signInRole} onValueChange={setSignInRole}>
                    <SelectTrigger className="border-[#0A1F44]/20 focus:border-[#90EE90] focus:ring-[#90EE90]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="student">Student</SelectItem>
                      <SelectItem value="student_coordinator">Student Coordinator</SelectItem>
                      <SelectItem value="faculty">Faculty</SelectItem>
                      <SelectItem value="staff_coordinator">Staff Coordinator</SelectItem>
                      <SelectItem value="hod">HOD (Head of Department)</SelectItem>
                      <SelectItem value="principal">Principal</SelectItem>
                      <SelectItem value="admin">Administrator</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Email */}
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-[#0A1F44] font-semibold flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    Email / Register Number
                  </Label>
                  <Input
                    id="email"
                    type="text"
                    value={signInEmail}
                    onChange={(e) => setSignInEmail(e.target.value)}
                    placeholder="Enter your email or register number"
                    className="border-[#0A1F44]/20 focus:border-[#90EE90] focus:ring-[#90EE90]"
                    required
                  />
                </div>

                {/* Password */}
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-[#0A1F44] font-semibold flex items-center gap-2">
                    <Lock className="w-4 h-4" />
                    Password
                  </Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? 'text' : 'password'}
                      value={signInPassword}
                      onChange={(e) => setSignInPassword(e.target.value)}
                      placeholder="••••••••••"
                      className="border-[#0A1F44]/20 focus:border-[#90EE90] focus:ring-[#90EE90] pr-10"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-[#0A1F44]"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Forgot Password */}
                <div className="flex items-center justify-end text-sm">
                  <button type="button" className="text-[#0A1F44] hover:text-[#90EE90] font-medium">
                    Forgot Password?
                  </button>
                </div>

                {/* Submit Button */}
                <Button
                  type="submit"
                  className="w-full bg-[#0A1F44] hover:bg-[#1a3a5c] text-white font-semibold py-6 text-base"
                >
                  <Lock className="w-4 h-4 mr-2" />
                  SIGN IN →
                </Button>
              </form>
            </TabsContent>

            {/* SIGN UP TAB */}
            <TabsContent value="signup">
              <Tabs defaultValue="student" className="w-full">
                <TabsList className="grid w-full grid-cols-2 mb-4">
                  <TabsTrigger value="student">Student</TabsTrigger>
                  <TabsTrigger value="staff">Staff/Faculty/Admin</TabsTrigger>
                </TabsList>

                {/* STUDENT SIGN UP */}
                <TabsContent value="student">
                  <form onSubmit={handleSignUp} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="studentName">Full Name *</Label>
                        <Input
                          id="studentName"
                          value={studentName}
                          onChange={(e) => setStudentName(e.target.value)}
                          placeholder="John Doe"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="studentRegNo">Register Number *</Label>
                        <Input
                          id="studentRegNo"
                          value={studentRegNo}
                          onChange={(e) => setStudentRegNo(e.target.value)}
                          placeholder="2021CSE001"
                          required
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="studentEmail">Email *</Label>
                        <Input
                          id="studentEmail"
                          type="email"
                          value={studentEmail}
                          onChange={(e) => setStudentEmail(e.target.value)}
                          placeholder="john@student.cit.edu"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="studentPhone">Phone Number *</Label>
                        <Input
                          id="studentPhone"
                          type="tel"
                          value={studentPhone}
                          onChange={(e) => setStudentPhone(e.target.value)}
                          placeholder="9876543210"
                          required
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="studentDept">Department *</Label>
                        <Select value={studentDept} onValueChange={setStudentDept}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select department" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="cse">Computer Science (CSE)</SelectItem>
                            <SelectItem value="ece">Electronics (ECE)</SelectItem>
                            <SelectItem value="eee">Electrical (EEE)</SelectItem>
                            <SelectItem value="mech">Mechanical (MECH)</SelectItem>
                            <SelectItem value="civil">Civil (CIVIL)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="studentBatch">Batch/Year *</Label>
                        <Select value={studentBatch} onValueChange={setStudentBatch}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select batch" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="2021">2021-2025 (4th Year)</SelectItem>
                            <SelectItem value="2022">2022-2026 (3rd Year)</SelectItem>
                            <SelectItem value="2023">2023-2027 (2nd Year)</SelectItem>
                            <SelectItem value="2024">2024-2028 (1st Year)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="studentPassword">Password *</Label>
                      <Input
                        id="studentPassword"
                        type="password"
                        value={studentPassword}
                        onChange={(e) => setStudentPassword(e.target.value)}
                        placeholder="Create a strong password"
                        required
                      />
                    </div>

                    <Button type="submit" className="w-full bg-[#0A1F44] hover:bg-[#1a3a5c]">
                      Create Student Account
                    </Button>
                  </form>
                </TabsContent>

                {/* STAFF SIGN UP */}
                <TabsContent value="staff">
                  <form onSubmit={handleSignUp} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="staffRole">Role *</Label>
                      <Select value={staffRole} onValueChange={setStaffRole}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="faculty">Faculty</SelectItem>
                          <SelectItem value="staff_coordinator">Staff Coordinator</SelectItem>
                          <SelectItem value="hod">HOD</SelectItem>
                          <SelectItem value="admin">Admin</SelectItem>
                          <SelectItem value="principal">Principal</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="staffName">Full Name *</Label>
                      <Input
                        id="staffName"
                        value={staffName}
                        onChange={(e) => setStaffName(e.target.value)}
                        placeholder="Dr. John Smith"
                        required
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="staffEmail">Email *</Label>
                        <Input
                          id="staffEmail"
                          type="email"
                          value={staffEmail}
                          onChange={(e) => setStaffEmail(e.target.value)}
                          placeholder="john@cit.edu"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="staffPhone">Phone Number *</Label>
                        <Input
                          id="staffPhone"
                          type="tel"
                          value={staffPhone}
                          onChange={(e) => setStaffPhone(e.target.value)}
                          placeholder="9876543210"
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="staffDept">Department *</Label>
                      <Select value={staffDept} onValueChange={setStaffDept}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select department" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="cse">Computer Science (CSE)</SelectItem>
                          <SelectItem value="ece">Electronics (ECE)</SelectItem>
                          <SelectItem value="eee">Electrical (EEE)</SelectItem>
                          <SelectItem value="mech">Mechanical (MECH)</SelectItem>
                          <SelectItem value="civil">Civil (CIVIL)</SelectItem>
                          <SelectItem value="admin">Administration</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="staffPassword">Password *</Label>
                      <Input
                        id="staffPassword"
                        type="password"
                        value={staffPassword}
                        onChange={(e) => setStaffPassword(e.target.value)}
                        placeholder="Create a strong password"
                        required
                      />
                    </div>

                    <Button type="submit" className="w-full bg-[#0A1F44] hover:bg-[#1a3a5c]">
                      Create Staff Account
                    </Button>
                  </form>
                </TabsContent>
              </Tabs>
            </TabsContent>
          </Tabs>
        </div>
      </Card>
    </div>
  );
}