import { useState } from 'react';
import { FileText, Download, Mail, Eye, Calendar, Filter, CheckSquare } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Checkbox } from '../components/ui/checkbox';
import { Label } from '../components/ui/label';
import { Input } from '../components/ui/input';

const reportTypes = [
  { id: 'executive', name: 'Executive Summary', description: 'High-level overview for leadership' },
  { id: 'utilization', name: 'Department-wise Utilization', description: 'Detailed budget usage by department' },
  { id: 'asset', name: 'Asset Inventory Report', description: 'Complete list of all assets' },
  { id: 'approval', name: 'Approval Logs', description: 'Approval workflow history' },
  { id: 'audit', name: 'Audit Trail', description: 'Complete transaction audit log' },
  { id: 'vendor', name: 'Vendor Performance', description: 'Vendor analysis and ratings' },
  { id: 'compliance', name: 'Compliance Report', description: 'Regulatory compliance status' },
  { id: 'forecast', name: 'Budget Forecast', description: 'Projected spending analysis' },
];

const savedReports = [
  {
    id: 'RPT-001',
    name: 'Q4 Executive Summary',
    type: 'Executive Summary',
    generatedOn: '2026-02-28',
    format: 'PDF',
    size: '2.4 MB',
  },
  {
    id: 'RPT-002',
    name: 'Asset Inventory - Jan 2026',
    type: 'Asset Inventory',
    generatedOn: '2026-02-01',
    format: 'Excel',
    size: '856 KB',
  },
  {
    id: 'RPT-003',
    name: 'Budget Utilization - CSE',
    type: 'Utilization Report',
    generatedOn: '2026-02-25',
    format: 'PDF',
    size: '1.2 MB',
  },
];

export default function ReportGenerator() {
  const [selectedReports, setSelectedReports] = useState<string[]>(['executive', 'utilization', 'asset', 'approval', 'audit']);
  const [fiscalYear, setFiscalYear] = useState('fy2025');
  const [department, setDepartment] = useState('all');
  const [category, setCategory] = useState('all');
  const [format, setFormat] = useState('pdf');

  const toggleReport = (reportId: string) => {
    setSelectedReports((prev) =>
      prev.includes(reportId) ? prev.filter((id) => id !== reportId) : [...prev, reportId]
    );
  };

  const handleGenerate = () => {
    alert(`Generating ${selectedReports.length} reports in ${format.toUpperCase()} format...`);
  };

  const handlePreview = () => {
    alert('Opening report preview...');
  };

  const handleEmail = () => {
    alert('Email stakeholders dialog...');
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-3xl font-bold text-[#0A1F44]">Report Generator</h1>
        <p className="text-gray-600 mt-1">Generate comprehensive financial and operational reports</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Report Configuration */}
        <div className="lg:col-span-2 space-y-6">
          {/* Filters */}
          <Card className="border-t-4 border-t-[#0A1F44]">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="w-5 h-5 text-[#0A1F44]" />
                Report Filters
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Fiscal Year */}
                <div className="space-y-2">
                  <Label htmlFor="fiscalYear">Fiscal Year</Label>
                  <Select value={fiscalYear} onValueChange={setFiscalYear}>
                    <SelectTrigger id="fiscalYear">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fy2025">FY 2025-26</SelectItem>
                      <SelectItem value="fy2024">FY 2024-25</SelectItem>
                      <SelectItem value="fy2023">FY 2023-24</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Department */}
                <div className="space-y-2">
                  <Label htmlFor="department">Department</Label>
                  <Select value={department} onValueChange={setDepartment}>
                    <SelectTrigger id="department">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Departments</SelectItem>
                      <SelectItem value="cse">CSE</SelectItem>
                      <SelectItem value="mech">MECH</SelectItem>
                      <SelectItem value="civil">CIVIL</SelectItem>
                      <SelectItem value="ece">ECE</SelectItem>
                      <SelectItem value="eee">EEE</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Category */}
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select value={category} onValueChange={setCategory}>
                    <SelectTrigger id="category">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      <SelectItem value="equipment">Equipment</SelectItem>
                      <SelectItem value="software">Software</SelectItem>
                      <SelectItem value="consumables">Consumables</SelectItem>
                      <SelectItem value="events">Events</SelectItem>
                      <SelectItem value="travel">Travel</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Format */}
                <div className="space-y-2">
                  <Label htmlFor="format">Output Format</Label>
                  <Select value={format} onValueChange={setFormat}>
                    <SelectTrigger id="format">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pdf">PDF Document</SelectItem>
                      <SelectItem value="excel">Excel Spreadsheet</SelectItem>
                      <SelectItem value="csv">CSV File</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Date Range */}
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="startDate">Start Date</Label>
                  <Input id="startDate" type="date" defaultValue="2025-08-01" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="endDate">End Date</Label>
                  <Input id="endDate" type="date" defaultValue="2026-02-28" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Report Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckSquare className="w-5 h-5 text-[#0A1F44]" />
                Select Reports to Generate
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {reportTypes.map((report) => (
                  <div
                    key={report.id}
                    className="flex items-start gap-3 p-4 border border-gray-200 rounded-lg hover:border-[#0A1F44] transition-colors cursor-pointer"
                    onClick={() => toggleReport(report.id)}
                  >
                    <Checkbox
                      checked={selectedReports.includes(report.id)}
                      onCheckedChange={() => toggleReport(report.id)}
                      className="mt-1"
                    />
                    <div className="flex-1">
                      <p className="font-semibold text-[#0A1F44]">{report.name}</p>
                      <p className="text-sm text-gray-600">{report.description}</p>
                    </div>
                    <FileText className="w-5 h-5 text-gray-400" />
                  </div>
                ))}
              </div>

              {/* Selection Summary */}
              <div className="mt-6 p-4 bg-[#90EE90]/10 border border-[#90EE90] rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-[#0A1F44]">
                      {selectedReports.length} Reports Selected
                    </p>
                    <p className="text-sm text-gray-600">
                      Format: {format.toUpperCase()} | Period: {fiscalYear === 'fy2025' ? 'FY 2025-26' : fiscalYear}
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedReports(reportTypes.map((r) => r.id))}
                  >
                    Select All
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <Card className="bg-gradient-to-r from-[#0A1F44] to-[#1a3a5c] text-white">
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row gap-3">
                <Button
                  className="flex-1 bg-white text-[#0A1F44] hover:bg-gray-100"
                  size="lg"
                  onClick={handleGenerate}
                  disabled={selectedReports.length === 0}
                >
                  <Download className="w-5 h-5 mr-2" />
                  Generate & Download
                </Button>
                <Button
                  variant="outline"
                  className="flex-1 border-white text-white hover:bg-white/10"
                  size="lg"
                  onClick={handlePreview}
                  disabled={selectedReports.length === 0}
                >
                  <Eye className="w-5 h-5 mr-2" />
                  Preview Reports
                </Button>
                <Button
                  variant="outline"
                  className="flex-1 border-white text-white hover:bg-white/10"
                  size="lg"
                  onClick={handleEmail}
                  disabled={selectedReports.length === 0}
                >
                  <Mail className="w-5 h-5 mr-2" />
                  Email Stakeholders
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar - Saved Reports & Quick Actions */}
        <div className="space-y-6">
          {/* Quick Stats */}
          <Card className="border-t-4 border-t-[#90EE90]">
            <CardHeader>
              <CardTitle className="text-sm">Report Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Total Reports</span>
                  <span className="font-bold text-[#0A1F44]">8</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Selected</span>
                  <span className="font-bold text-[#90EE90]">{selectedReports.length}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Est. Size</span>
                  <span className="font-bold text-[#0A1F44]">~{selectedReports.length * 1.5} MB</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Processing Time</span>
                  <span className="font-bold text-[#0A1F44]">~{selectedReports.length * 2}s</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Saved Reports */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-[#0A1F44]" />
                Recent Reports
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {savedReports.map((report) => (
                  <div
                    key={report.id}
                    className="p-3 border border-gray-200 rounded-lg hover:border-[#0A1F44] transition-colors cursor-pointer"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <p className="font-semibold text-sm text-[#0A1F44]">{report.name}</p>
                        <p className="text-xs text-gray-600">{report.type}</p>
                      </div>
                      <FileText className="w-4 h-4 text-gray-400" />
                    </div>
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>{new Date(report.generatedOn).toLocaleDateString('en-IN')}</span>
                      <span className="font-mono">{report.size}</span>
                    </div>
                    <div className="flex gap-2 mt-2">
                      <Button variant="outline" size="sm" className="flex-1 text-xs">
                        <Download className="w-3 h-3 mr-1" />
                        Download
                      </Button>
                      <Button variant="outline" size="sm" className="flex-1 text-xs">
                        <Eye className="w-3 h-3 mr-1" />
                        View
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Scheduled Reports */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Scheduled Reports</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <div className="p-3 bg-gray-50 rounded-lg">
                  <p className="font-semibold mb-1">Monthly Executive Summary</p>
                  <p className="text-xs text-gray-600">Next: Mar 1, 2026</p>
                  <p className="text-xs text-[#90EE90] mt-1">Auto-send to Principal</p>
                </div>
                <div className="p-3 bg-gray-50 rounded-lg">
                  <p className="font-semibold mb-1">Quarterly Audit Trail</p>
                  <p className="text-xs text-gray-600">Next: Mar 31, 2026</p>
                  <p className="text-xs text-[#90EE90] mt-1">Auto-send to Finance</p>
                </div>
              </div>
              <Button variant="outline" size="sm" className="w-full mt-3">
                Manage Schedule
              </Button>
            </CardContent>
          </Card>

          {/* Email Recipients */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-sm">
                <Mail className="w-4 h-4" />
                Email Recipients
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <label className="flex items-center gap-2 cursor-pointer">
                  <Checkbox defaultChecked />
                  <span>Principal</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <Checkbox defaultChecked />
                  <span>Finance Officer</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <Checkbox />
                  <span>All HODs</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <Checkbox />
                  <span>Auditor</span>
                </label>
              </div>
              <Input
                placeholder="Add custom email..."
                className="mt-3 text-sm"
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
