import { useState } from 'react';
import { Wallet, TrendingDown, TrendingUp, AlertTriangle, Plus, Filter, Calendar } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Progress } from '../components/ui/progress';
import { Badge } from '../components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Textarea } from '../components/ui/textarea';

const transactions = [
  {
    id: 'TXN-001',
    item: 'Laptop (Qty 5)',
    amount: 125000,
    status: 'approved',
    date: '2026-01-15',
    category: 'Equipment',
    linkedAsset: 'CST-001 to CST-005',
  },
  {
    id: 'TXN-002',
    item: 'Seminar Expenses',
    amount: 25000,
    status: 'pending',
    date: '2026-02-20',
    category: 'Events',
    linkedAsset: null,
  },
  {
    id: 'TXN-003',
    item: 'Lab Consumables',
    amount: 45000,
    status: 'approved',
    date: '2026-01-10',
    category: 'Consumables',
    linkedAsset: null,
  },
  {
    id: 'TXN-004',
    item: 'Software Licenses',
    amount: 180000,
    status: 'committed',
    date: '2026-02-01',
    category: 'Software',
    linkedAsset: null,
  },
];

export default function BudgetWallet() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showAddExpense, setShowAddExpense] = useState(false);

  const totalBudget = 500000;
  const available = 27500;
  const committed = 230000;
  const approved = 235000;
  const spent = 372500;

  const utilizationPercent = ((spent + approved) / totalBudget) * 100;

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#0A1F44]">Digital Budget Wallet</h1>
          <p className="text-gray-600 mt-1">CSE Department - FY 2025-26</p>
        </div>
        <Dialog open={showAddExpense} onOpenChange={setShowAddExpense}>
          <DialogTrigger asChild>
            <Button className="bg-[#0A1F44] hover:bg-[#1a3a5c]">
              <Plus className="w-4 h-4 mr-2" />
              Add Expense
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Add New Expense</DialogTitle>
            </DialogHeader>
            <form className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="item">Item/Description</Label>
                <Input id="item" placeholder="e.g., Office Supplies" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="amount">Amount (₹)</Label>
                <Input id="amount" type="number" placeholder="0" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="category">Budget Head</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="equipment">Equipment</SelectItem>
                    <SelectItem value="consumables">Consumables</SelectItem>
                    <SelectItem value="events">Events</SelectItem>
                    <SelectItem value="software">Software</SelectItem>
                    <SelectItem value="travel">Travel</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="justification">Justification</Label>
                <Textarea id="justification" placeholder="Reason for expense..." rows={3} />
              </div>
              <div className="flex gap-2">
                <Button type="button" className="flex-1 bg-[#0A1F44]">Submit</Button>
                <Button type="button" variant="outline" onClick={() => setShowAddExpense(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Budget Overview Card */}
      <Card className="border-t-4 border-t-[#0A1F44]">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Wallet className="w-6 h-6 text-[#0A1F44]" />
              ₹5,00,000 Total Allocation
            </span>
            <Badge variant={utilizationPercent > 90 ? 'destructive' : utilizationPercent > 75 ? 'default' : 'secondary'}>
              {utilizationPercent.toFixed(1)}% Utilized
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Budget Breakdown */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Available</span>
                <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">🟢</span>
              </div>
              <p className="text-2xl font-bold text-green-600">₹{available.toLocaleString()}</p>
              <Progress value={(available / totalBudget) * 100} className="h-2 bg-green-100" />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Committed</span>
                <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">🔵</span>
              </div>
              <p className="text-2xl font-bold text-blue-600">₹{committed.toLocaleString()}</p>
              <Progress value={(committed / totalBudget) * 100} className="h-2 bg-blue-100" />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Approved</span>
                <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-1 rounded">🟡</span>
              </div>
              <p className="text-2xl font-bold text-yellow-600">₹{approved.toLocaleString()}</p>
              <Progress value={(approved / totalBudget) * 100} className="h-2 bg-yellow-100" />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Spent</span>
                <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded">🔴</span>
              </div>
              <p className="text-2xl font-bold text-red-600">₹{spent.toLocaleString()}</p>
              <Progress value={(spent / totalBudget) * 100} className="h-2 bg-red-100" />
            </div>
          </div>

          {/* Visual Progress Bar */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium">Overall Budget Status</span>
              <span className="text-gray-600">{utilizationPercent.toFixed(1)}% of ₹5L</span>
            </div>
            <div className="h-8 bg-gray-100 rounded-full overflow-hidden flex">
              <div 
                className="bg-red-500 flex items-center justify-center text-xs text-white font-medium"
                style={{ width: `${(spent / totalBudget) * 100}%` }}
              >
                {spent > 50000 && 'Spent'}
              </div>
              <div 
                className="bg-yellow-500 flex items-center justify-center text-xs text-white font-medium"
                style={{ width: `${(approved / totalBudget) * 100}%` }}
              >
                {approved > 50000 && 'Approved'}
              </div>
              <div 
                className="bg-blue-500 flex items-center justify-center text-xs text-white font-medium"
                style={{ width: `${(committed / totalBudget) * 100}%` }}
              >
                {committed > 50000 && 'Committed'}
              </div>
              <div 
                className="bg-green-500 flex items-center justify-center text-xs text-white font-medium"
                style={{ width: `${(available / totalBudget) * 100}%` }}
              >
                {available > 20000 && 'Available'}
              </div>
            </div>
          </div>

          {/* Alerts */}
          {available < 50000 && (
            <div className="flex items-center gap-3 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-yellow-600 flex-shrink-0" />
              <div>
                <p className="font-semibold text-yellow-800">Low Balance Warning</p>
                <p className="text-sm text-yellow-700">Only ₹{available.toLocaleString()} remaining. Consider budget reallocation.</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Transaction Timeline */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-[#0A1F44]" />
              Transaction Timeline
            </CardTitle>
            <div className="flex items-center gap-2">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="equipment">Equipment</SelectItem>
                  <SelectItem value="consumables">Consumables</SelectItem>
                  <SelectItem value="events">Events</SelectItem>
                  <SelectItem value="software">Software</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="sm">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {transactions.map((txn) => (
              <div
                key={txn.id}
                className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:border-[#0A1F44] transition-colors"
              >
                <div className="flex items-center gap-4 flex-1">
                  <div className={`w-3 h-3 rounded-full ${
                    txn.status === 'approved' ? 'bg-green-500' :
                    txn.status === 'pending' ? 'bg-yellow-500' :
                    txn.status === 'committed' ? 'bg-blue-500' : 'bg-gray-500'
                  }`}></div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-1">
                      <p className="font-semibold">{txn.item}</p>
                      <Badge variant="outline" className="text-xs">{txn.category}</Badge>
                      <Badge 
                        variant={
                          txn.status === 'approved' ? 'default' :
                          txn.status === 'pending' ? 'secondary' : 'outline'
                        }
                        className="text-xs uppercase"
                      >
                        {txn.status}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-gray-600">
                      <span className="font-mono text-xs">{txn.id}</span>
                      <span>{new Date(txn.date).toLocaleDateString('en-IN')}</span>
                      {txn.linkedAsset && (
                        <span className="text-[#90EE90] font-medium">→ Asset: {txn.linkedAsset}</span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <p className="text-xl font-bold text-[#0A1F44]">
                    ₹{txn.amount.toLocaleString()}
                  </p>
                  {txn.status === 'approved' && txn.linkedAsset && (
                    <p className="text-xs text-green-600 font-medium mt-1">ASSET LINKED ✓</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Category-wise Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-3">
              <span className="font-semibold">Equipment</span>
              <span className="text-2xl font-bold text-[#0A1F44]">₹3.2L</span>
            </div>
            <Progress value={64} className="h-2" />
            <p className="text-sm text-gray-600 mt-2">64% of total budget</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-3">
              <span className="font-semibold">Software</span>
              <span className="text-2xl font-bold text-[#0A1F44]">₹1.8L</span>
            </div>
            <Progress value={36} className="h-2" />
            <p className="text-sm text-gray-600 mt-2">36% of total budget</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-3">
              <span className="font-semibold">Events</span>
              <span className="text-2xl font-bold text-[#0A1F44]">₹45K</span>
            </div>
            <Progress value={9} className="h-2" />
            <p className="text-sm text-gray-600 mt-2">9% of total budget</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
