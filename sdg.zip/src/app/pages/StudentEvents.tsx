import { useState } from 'react';
import { Calendar, Clock, MapPin, Users, Search, Filter, ExternalLink, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Progress } from '../components/ui/progress';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

const events = [
  {
    id: 'EVT-001',
    name: 'TechFest 2026',
    type: 'Technical',
    category: 'Fest',
    department: 'CSE',
    date: '2026-03-15',
    time: '09:00 AM',
    venue: 'Main Auditorium',
    description: 'Annual technical festival featuring coding competitions, hackathons, and tech talks.',
    poster: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=400',
    registrationDeadline: '2026-03-10',
    totalSeats: 500,
    seatsBooked: 347,
    coordinator: 'Rahul Kumar',
    registrationLink: '#',
    status: 'open',
    tags: ['Coding', 'Hackathon', 'Tech Talk'],
  },
  {
    id: 'EVT-002',
    name: 'Cultural Evening',
    type: 'Cultural',
    category: 'Event',
    department: 'Arts',
    date: '2026-03-20',
    time: '06:00 PM',
    venue: 'Open Air Theatre',
    description: 'Traditional and modern dance performances, music concerts, and drama.',
    poster: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=400',
    registrationDeadline: '2026-03-18',
    totalSeats: 300,
    seatsBooked: 289,
    coordinator: 'Priya Sharma',
    registrationLink: '#',
    status: 'open',
    tags: ['Dance', 'Music', 'Drama'],
  },
  {
    id: 'EVT-003',
    name: 'Workshop: AI & ML',
    type: 'Workshop',
    category: 'Workshop',
    department: 'CSE',
    date: '2026-03-08',
    time: '10:00 AM',
    venue: 'Lab 301',
    description: 'Hands-on workshop on Machine Learning fundamentals and practical applications.',
    poster: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=400',
    registrationDeadline: '2026-03-05',
    totalSeats: 50,
    seatsBooked: 48,
    coordinator: 'Dr. Anand Kumar',
    registrationLink: '#',
    status: 'urgent',
    tags: ['AI', 'ML', 'Hands-on'],
  },
  {
    id: 'EVT-004',
    name: 'Sports Meet 2026',
    type: 'Sports',
    category: 'Sports',
    department: 'Physical Education',
    date: '2026-04-01',
    time: '07:00 AM',
    venue: 'Sports Ground',
    description: 'Inter-department sports competition including cricket, football, and athletics.',
    poster: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=400',
    registrationDeadline: '2026-03-25',
    totalSeats: 200,
    seatsBooked: 95,
    coordinator: 'Coach Ramesh',
    registrationLink: '#',
    status: 'open',
    tags: ['Cricket', 'Football', 'Athletics'],
  },
  {
    id: 'EVT-005',
    name: 'Entrepreneurship Summit',
    type: 'Seminar',
    category: 'Seminar',
    department: 'Management',
    date: '2026-03-12',
    time: '02:00 PM',
    venue: 'Conference Hall',
    description: 'Learn from successful entrepreneurs and industry leaders about startup ecosystem.',
    poster: 'https://images.unsplash.com/photo-1475721027785-f74eccf877e2?w=400',
    registrationDeadline: '2026-03-09',
    totalSeats: 150,
    seatsBooked: 142,
    coordinator: 'Prof. Meera Singh',
    registrationLink: '#',
    status: 'urgent',
    tags: ['Startup', 'Business', 'Networking'],
  },
  {
    id: 'EVT-006',
    name: 'Project Expo',
    type: 'Exhibition',
    category: 'Expo',
    department: 'All',
    date: '2026-04-10',
    time: '11:00 AM',
    venue: 'Exhibition Hall',
    description: 'Showcase your innovative projects to industry experts and get feedback.',
    poster: 'https://images.unsplash.com/photo-1559223607-a43c990c61e3?w=400',
    registrationDeadline: '2026-04-05',
    totalSeats: 100,
    seatsBooked: 34,
    coordinator: 'Team Innovation',
    registrationLink: '#',
    status: 'open',
    tags: ['Projects', 'Innovation', 'Showcase'],
  },
];

export default function StudentEvents() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterDepartment, setFilterDepartment] = useState('all');

  const filteredEvents = events.filter(event => {
    const matchesSearch = event.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         event.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || event.type === filterType;
    const matchesCategory = filterCategory === 'all' || event.category === filterCategory;
    const matchesDepartment = filterDepartment === 'all' || event.department === filterDepartment;
    
    return matchesSearch && matchesType && matchesCategory && matchesDepartment;
  });

  const getDaysUntilDeadline = (deadline: string) => {
    const today = new Date();
    const deadlineDate = new Date(deadline);
    const diffTime = deadlineDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const getDeadlineColor = (days: number) => {
    if (days < 0) return 'text-gray-500';
    if (days <= 2) return 'text-red-600';
    if (days <= 5) return 'text-orange-600';
    return 'text-green-600';
  };

  const getStatusBadge = (status: string) => {
    if (status === 'urgent') return <Badge className="bg-red-500 text-white">Urgent</Badge>;
    if (status === 'open') return <Badge className="bg-green-500 text-white">Open</Badge>;
    return <Badge className="bg-gray-500 text-white">Closed</Badge>;
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-3xl font-bold text-[#0A1F44]">Event Discovery Hub</h1>
        <p className="text-gray-600 mt-1">Explore and register for upcoming campus events</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-l-4 border-l-[#0A1F44]">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Events</p>
                <p className="text-3xl font-bold text-[#0A1F44]">{events.length}</p>
              </div>
              <Calendar className="w-10 h-10 text-[#0A1F44]" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Open for Registration</p>
                <p className="text-3xl font-bold text-green-600">
                  {events.filter(e => e.status === 'open').length}
                </p>
              </div>
              <ExternalLink className="w-10 h-10 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-red-500">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Urgent</p>
                <p className="text-3xl font-bold text-red-600">
                  {events.filter(e => e.status === 'urgent').length}
                </p>
              </div>
              <AlertCircle className="w-10 h-10 text-red-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-[#90EE90]">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">My Registrations</p>
                <p className="text-3xl font-bold text-[#90EE90]">3</p>
              </div>
              <Users className="w-10 h-10 text-[#90EE90]" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Search */}
            <div className="md:col-span-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search events..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            {/* Type Filter */}
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger>
                <SelectValue placeholder="Event Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="Technical">Technical</SelectItem>
                <SelectItem value="Cultural">Cultural</SelectItem>
                <SelectItem value="Sports">Sports</SelectItem>
                <SelectItem value="Workshop">Workshop</SelectItem>
                <SelectItem value="Seminar">Seminar</SelectItem>
                <SelectItem value="Exhibition">Exhibition</SelectItem>
              </SelectContent>
            </Select>

            {/* Category Filter */}
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="Fest">Fest</SelectItem>
                <SelectItem value="Event">Event</SelectItem>
                <SelectItem value="Workshop">Workshop</SelectItem>
                <SelectItem value="Sports">Sports</SelectItem>
                <SelectItem value="Seminar">Seminar</SelectItem>
                <SelectItem value="Expo">Expo</SelectItem>
              </SelectContent>
            </Select>

            {/* Department Filter */}
            <Select value={filterDepartment} onValueChange={setFilterDepartment}>
              <SelectTrigger>
                <SelectValue placeholder="Department" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Departments</SelectItem>
                <SelectItem value="CSE">CSE</SelectItem>
                <SelectItem value="ECE">ECE</SelectItem>
                <SelectItem value="EEE">EEE</SelectItem>
                <SelectItem value="MECH">MECH</SelectItem>
                <SelectItem value="CIVIL">CIVIL</SelectItem>
                <SelectItem value="Arts">Arts</SelectItem>
                <SelectItem value="Management">Management</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Event Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredEvents.map((event) => {
          const seatsPercentage = (event.seatsBooked / event.totalSeats) * 100;
          const daysUntilDeadline = getDaysUntilDeadline(event.registrationDeadline);
          
          return (
            <Card key={event.id} className="overflow-hidden hover:shadow-xl transition-shadow">
              {/* Event Poster */}
              <div className="relative h-48 overflow-hidden bg-gray-200">
                <ImageWithFallback 
                  src={event.poster} 
                  alt={event.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 right-3">
                  {getStatusBadge(event.status)}
                </div>
                <div className="absolute top-3 left-3">
                  <Badge variant="outline" className="bg-white/90">
                    {event.type}
                  </Badge>
                </div>
              </div>

              <CardContent className="pt-4">
                {/* Event Name */}
                <h3 className="text-xl font-bold text-[#0A1F44] mb-2">{event.name}</h3>
                
                {/* Tags */}
                <div className="flex flex-wrap gap-2 mb-3">
                  {event.tags.map((tag, idx) => (
                    <Badge key={idx} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>

                {/* Description */}
                <p className="text-sm text-gray-600 mb-4 line-clamp-2">{event.description}</p>

                {/* Event Details */}
                <div className="space-y-2 mb-4 text-sm">
                  <div className="flex items-center gap-2 text-gray-700">
                    <Calendar className="w-4 h-4 text-[#0A1F44]" />
                    <span>{new Date(event.date).toLocaleDateString('en-IN', { 
                      weekday: 'short', 
                      year: 'numeric', 
                      month: 'short', 
                      day: 'numeric' 
                    })}</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-700">
                    <Clock className="w-4 h-4 text-[#0A1F44]" />
                    <span>{event.time}</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-700">
                    <MapPin className="w-4 h-4 text-[#0A1F44]" />
                    <span>{event.venue}</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-700">
                    <Users className="w-4 h-4 text-[#0A1F44]" />
                    <span>{event.coordinator}</span>
                  </div>
                </div>

                {/* Seat Availability */}
                <div className="mb-4">
                  <div className="flex items-center justify-between text-sm mb-2">
                    <span className="text-gray-600">Seat Availability</span>
                    <span className="font-semibold">
                      {event.totalSeats - event.seatsBooked} / {event.totalSeats} left
                    </span>
                  </div>
                  <Progress 
                    value={seatsPercentage} 
                    className={`h-2 ${seatsPercentage > 90 ? 'bg-red-100' : 'bg-green-100'}`}
                  />
                </div>

                {/* Registration Deadline */}
                <div className={`text-sm font-semibold mb-4 ${getDeadlineColor(daysUntilDeadline)}`}>
                  {daysUntilDeadline < 0 ? (
                    <span className="flex items-center gap-1">
                      <AlertCircle className="w-4 h-4" />
                      Registration Closed
                    </span>
                  ) : (
                    <span>
                      Deadline: {daysUntilDeadline} {daysUntilDeadline === 1 ? 'day' : 'days'} left
                    </span>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex gap-2">
                  <Button 
                    className="flex-1 bg-[#0A1F44] hover:bg-[#1a3a5c]"
                    disabled={daysUntilDeadline < 0 || seatsPercentage === 100}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Register Now
                  </Button>
                  <Button variant="outline" size="sm">
                    Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Empty State */}
      {filteredEvents.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <AlertCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No Events Found</h3>
            <p className="text-gray-600">Try adjusting your filters or search criteria</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
