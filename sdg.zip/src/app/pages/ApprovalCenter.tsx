import { CheckCircle, XCircle, Clock, Send, MessageSquare, FileText, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Textarea } from '../components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Label } from '../components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';

const pendingApprovals = [
  {
    id: 'REQ-123',
    type: 'Procurement',
    title: 'Projector - Faculty A',
    amount: 45000,
    requestedBy: 'Dr. Sharma',
    department: 'CSE',
    submittedOn: '2026-02-26',
    daysAgo: 2,
    priority: 'high',
    description: 'Epson EB-2250U projector for seminar hall',
    justification: 'Required for upcoming seminar series and guest lectures',
    budgetHead: 'Equipment',
    documents: ['Quote.pdf', 'Specifications.pdf'],
  },
  {
    id: 'REQ-124',
    type: 'Procurement',
    title: 'Lab Chemicals',
    amount: 12000,
    requestedBy: 'Student - John',
    department: 'Chemistry',
    submittedOn: '2026-02-27',
    daysAgo: 1,
    priority: 'medium',
    description: 'Various lab chemicals for practical sessions',
    justification: 'Stock replenishment for semester practicals',
    budgetHead: 'Consumables',
    documents: ['ChemicalList.pdf'],
  },
  {
    id: 'BUD-045',
    type: 'Budget Reallocation',
    title: 'Budget Transfer - MECH to CSE',
    amount: 25000,
    requestedBy: 'HOD - MECH',
    department: 'MECH',
    submittedOn: '2026-02-25',
    daysAgo: 3,
    priority: 'high',
    description: 'Transfer unused equipment budget to CSE',
    justification: 'Equipment purchase postponed, CSE needs additional funding',
    budgetHead: 'Reallocation',
    documents: ['Justification.pdf'],
  },
];

const approvalHistory = [
  {
    id: 'REQ-120',
    title: 'Laptop Purchase - 5 Units',
    amount: 125000,
    approvedBy: 'HOD - CSE',
    approvedOn: '2026-02-20',
    status: 'approved',
    comments: 'Approved for AI/ML lab upgrade',
  },
  {
    id: 'REQ-118',
    title: 'Conference Travel',
    amount: 35000,
    approvedBy: 'Principal',
    approvedOn: '2026-02-18',
    status: 'approved',
    comments: 'Approved for international conference',
  },
  {
    id: 'REQ-115',
    title: 'Software License Renewal',
    amount: 85000,
    approvedBy: 'Finance',
    approvedOn: '2026-02-15',
    status: 'rejected',
    comments: 'Budget not available, resubmit next quarter',
  },
];

export default function ApprovalCenter() {
  const handleApprove = (id: string) => {
    alert(`Request ${id} approved!`);
  };

  const handleReject = (id: string) => {
    alert(`Request ${id} rejected!`);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-700 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-700 border-green-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#0A1F44]">Approval Workflow Center</h1>
          <p className="text-gray-600 mt-1">Review and process pending requests - HOD View</p>
        </div>
        <Button variant="outline">
          <Send className="w-4 h-4 mr-2" />
          Delegate Authority
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-l-4 border-l-orange-500">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pending</p>
                <p className="text-3xl font-bold text-orange-600">3</p>
              </div>
              <Clock className="w-10 h-10 text-orange-500" />
            </div>
            <p className="text-xs text-gray-600 mt-2">Requires immediate action</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Approved Today</p>
                <p className="text-3xl font-bold text-green-600">2</p>
              </div>
              <CheckCircle className="w-10 h-10 text-green-500" />
            </div>
            <p className="text-xs text-gray-600 mt-2">This week: 12</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-red-500">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">High Priority</p>
                <p className="text-3xl font-bold text-red-600">2</p>
              </div>
              <AlertCircle className="w-10 h-10 text-red-500" />
            </div>
            <p className="text-xs text-gray-600 mt-2">Urgent attention needed</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-[#0A1F44]">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Amount</p>
                <p className="text-3xl font-bold text-[#0A1F44]">₹82K</p>
              </div>
              <FileText className="w-10 h-10 text-[#0A1F44]" />
            </div>
            <p className="text-xs text-gray-600 mt-2">Pending approvals</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="pending" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="pending">Pending Actions ({pendingApprovals.length})</TabsTrigger>
          <TabsTrigger value="history">Approval History</TabsTrigger>
        </TabsList>

        {/* Pending Approvals */}
        <TabsContent value="pending" className="space-y-4">
          {/* Bulk Actions */}
          <Card className="bg-gradient-to-r from-[#0A1F44] to-[#1a3a5c] text-white">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold mb-1">Bulk Actions Available</p>
                  <p className="text-sm text-gray-200">Select multiple requests to approve or reject together</p>
                </div>
                <div className="flex gap-2">
                  <Button variant="secondary" size="sm">
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Approve Selected
                  </Button>
                  <Button variant="destructive" size="sm">
                    <XCircle className="w-4 h-4 mr-2" />
                    Reject Selected
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Pending Requests List */}
          {pendingApprovals.map((request) => (
            <Card key={request.id} className="border-l-4 border-l-orange-500 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="space-y-4">
                  {/* Header */}
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-xl font-bold text-[#0A1F44]">{request.title}</h3>
                        <Badge className={getPriorityColor(request.priority)}>
                          {request.priority.toUpperCase()} PRIORITY
                        </Badge>
                        <Badge variant="outline">{request.type}</Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <span className="font-mono bg-gray-100 px-2 py-1 rounded">{request.id}</span>
                        <span>{request.requestedBy}</span>
                        <span>•</span>
                        <span>{request.department} Department</span>
                        <span>•</span>
                        <span className="flex items-center gap-1 text-orange-600">
                          <Clock className="w-3 h-3" />
                          {request.daysAgo} days ago
                        </span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-3xl font-bold text-[#0A1F44]">₹{request.amount.toLocaleString()}</p>
                      <p className="text-sm text-gray-600">{request.budgetHead}</p>
                    </div>
                  </div>

                  {/* Description */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
                    <div>
                      <p className="text-sm font-semibold text-gray-700 mb-1">Description</p>
                      <p className="text-sm text-gray-600">{request.description}</p>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-700 mb-1">Justification</p>
                      <p className="text-sm text-gray-600">{request.justification}</p>
                    </div>
                  </div>

                  {/* Documents */}
                  {request.documents && request.documents.length > 0 && (
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-gray-500" />
                      <span className="text-sm text-gray-600">Attachments:</span>
                      {request.documents.map((doc, idx) => (
                        <Badge key={idx} variant="secondary" className="cursor-pointer hover:bg-gray-300">
                          📎 {doc}
                        </Badge>
                      ))}
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex items-center gap-3 pt-4 border-t">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button className="flex-1 bg-green-600 hover:bg-green-700">
                          <CheckCircle className="w-4 h-4 mr-2" />
                          APPROVE
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Approve Request - {request.id}</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div className="p-4 bg-gray-50 rounded-lg">
                            <p className="font-semibold mb-1">{request.title}</p>
                            <p className="text-2xl font-bold text-green-600">₹{request.amount.toLocaleString()}</p>
                          </div>
                          <div className="space-y-2">
                            <Label>Approval Comments (Optional)</Label>
                            <Textarea placeholder="Add any comments or conditions..." rows={3} />
                          </div>
                          <div className="space-y-2">
                            <Label>Budget Allocation Confirmed</Label>
                            <div className="flex items-center gap-2">
                              <input type="checkbox" id="budget-check" className="rounded" />
                              <label htmlFor="budget-check" className="text-sm">
                                I confirm sufficient budget is available for this request
                              </label>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button 
                              className="flex-1 bg-green-600" 
                              onClick={() => handleApprove(request.id)}
                            >
                              Confirm Approval
                            </Button>
                            <Button variant="outline">Cancel</Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>

                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="destructive" className="flex-1">
                          <XCircle className="w-4 h-4 mr-2" />
                          REJECT
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Reject Request - {request.id}</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                            <p className="font-semibold mb-1">{request.title}</p>
                            <p className="text-2xl font-bold text-red-600">₹{request.amount.toLocaleString()}</p>
                          </div>
                          <div className="space-y-2">
                            <Label>Rejection Reason (Required)</Label>
                            <Textarea 
                              placeholder="Please provide a clear reason for rejection..." 
                              rows={4}
                              required
                            />
                          </div>
                          <div className="flex gap-2">
                            <Button 
                              variant="destructive" 
                              className="flex-1"
                              onClick={() => handleReject(request.id)}
                            >
                              Confirm Rejection
                            </Button>
                            <Button variant="outline">Cancel</Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>

                    <Button variant="outline">
                      <MessageSquare className="w-4 h-4 mr-2" />
                      Request Info
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        {/* Approval History */}
        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Approval History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {approvalHistory.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-4 border border-gray-200 rounded-lg"
                  >
                    <div className="flex items-center gap-4 flex-1">
                      {item.status === 'approved' ? (
                        <CheckCircle className="w-6 h-6 text-green-500" />
                      ) : (
                        <XCircle className="w-6 h-6 text-red-500" />
                      )}
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-1">
                          <p className="font-semibold">{item.title}</p>
                          <Badge
                            className={
                              item.status === 'approved'
                                ? 'bg-green-100 text-green-700'
                                : 'bg-red-100 text-red-700'
                            }
                          >
                            {item.status.toUpperCase()}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-gray-600">
                          <span className="font-mono">{item.id}</span>
                          <span>•</span>
                          <span>{item.approvedBy}</span>
                          <span>•</span>
                          <span>{new Date(item.approvedOn).toLocaleDateString('en-IN')}</span>
                        </div>
                        <p className="text-sm text-gray-600 mt-1 italic">"{item.comments}"</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xl font-bold text-[#0A1F44]">₹{item.amount.toLocaleString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Filter and Search */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex gap-4">
                <Button variant="outline" size="sm">This Week</Button>
                <Button variant="outline" size="sm">This Month</Button>
                <Button variant="outline" size="sm">Approved Only</Button>
                <Button variant="outline" size="sm">Rejected Only</Button>
                <Button variant="outline" size="sm" className="ml-auto">
                  Export Report
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Notification Settings */}
      <Card className="border-t-4 border-t-[#90EE90]">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-[#0A1F44]" />
            Notification Preferences
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <label className="flex items-center gap-3 cursor-pointer">
              <input type="checkbox" defaultChecked className="rounded" />
              <div>
                <p className="font-medium">Email Notifications</p>
                <p className="text-sm text-gray-600">Receive email for new pending approvals</p>
              </div>
            </label>
            <label className="flex items-center gap-3 cursor-pointer">
              <input type="checkbox" defaultChecked className="rounded" />
              <div>
                <p className="font-medium">SMS Alerts</p>
                <p className="text-sm text-gray-600">Get SMS for high-priority requests</p>
              </div>
            </label>
            <label className="flex items-center gap-3 cursor-pointer">
              <input type="checkbox" className="rounded" />
              <div>
                <p className="font-medium">Push Notifications</p>
                <p className="text-sm text-gray-600">Browser push for deadline reminders</p>
              </div>
            </label>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
