import { useState } from 'react';
import { Plus, Calendar, Upload, DollarSign, Package, FileText, Download } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Badge } from '../components/ui/badge';
import { Progress } from '../components/ui/progress';

const myEvents = [
  {
    id: 'EVT-001',
    name: 'TechFest 2026',
    date: '2026-03-15',
    budgetAllocated: 150000,
    budgetSpent: 87500,
    venue: 'Main Auditorium',
    status: 'active',
  },
  {
    id: 'EVT-003',
    name: 'Workshop: AI & ML',
    date: '2026-03-08',
    budgetAllocated: 25000,
    budgetSpent: 18000,
    venue: 'Lab 301',
    status: 'active',
  },
];

const assetRequirements = [
  { id: 1, name: 'Chairs', quantity: 500, allocated: 500, status: 'confirmed' },
  { id: 2, name: 'Tables', quantity: 50, allocated: 50, status: 'confirmed' },
  { id: 3, name: 'Projectors', quantity: 3, allocated: 2, status: 'pending' },
  { id: 4, name: 'Screens', quantity: 3, allocated: 2, status: 'pending' },
  { id: 5, name: 'Sound System', quantity: 1, allocated: 1, status: 'confirmed' },
  { id: 6, name: 'Microphones', quantity: 5, allocated: 5, status: 'confirmed' },
  { id: 7, name: 'Consoles', quantity: 2, allocated: 0, status: 'pending' },
  { id: 8, name: 'Lab Computers', quantity: 30, allocated: 30, status: 'confirmed' },
];

const receipts = [
  { id: 1, name: 'Printing_Invoice.pdf', date: '2026-02-15', amount: 12000, category: 'Printing' },
  { id: 2, name: 'Catering_Bill.pdf', date: '2026-02-20', amount: 45000, category: 'Catering' },
  { id: 3, name: 'Equipment_Rental.pdf', date: '2026-02-25', amount: 30500, category: 'Equipment' },
];

export default function CoordinatorDashboard() {
  const [showCreateEvent, setShowCreateEvent] = useState(false);
  
  // Event Form State
  const [eventName, setEventName] = useState('');
  const [eventDuration, setEventDuration] = useState('');
  const [eventTime, setEventTime] = useState('');
  const [eventDate, setEventDate] = useState('');
  const [eventHOD, setEventHOD] = useState('');
  const [eventStaffCoordinator, setEventStaffCoordinator] = useState('');
  const [eventVenue, setEventVenue] = useState('');
  const [eventBudget, setEventBudget] = useState('');
  const [equipmentRequired, setEquipmentRequired] = useState('');

  const handleCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Event created successfully!');
    setShowCreateEvent(false);
  };

  const totalBudget = myEvents.reduce((sum, event) => sum + event.budgetAllocated, 0);
  const totalSpent = myEvents.reduce((sum, event) => sum + event.budgetSpent, 0);
  const budgetUtilization = (totalSpent / totalBudget) * 100;

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#0A1F44]">Student Coordinator Dashboard</h1>
          <p className="text-gray-600 mt-1">Manage your events, budget, and requirements</p>
        </div>
        <Button 
          onClick={() => setShowCreateEvent(!showCreateEvent)}
          className="bg-[#0A1F44] hover:bg-[#1a3a5c]"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create New Event
        </Button>
      </div>

      {/* Budget Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-l-4 border-l-[#0A1F44]">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-600">Total Budget</span>
              <DollarSign className="w-5 h-5 text-[#0A1F44]" />
            </div>
            <p className="text-3xl font-bold text-[#0A1F44]">₹{totalBudget.toLocaleString()}</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-600">Budget Spent</span>
              <DollarSign className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-3xl font-bold text-green-600">₹{totalSpent.toLocaleString()}</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-600">Remaining</span>
              <DollarSign className="w-5 h-5 text-blue-600" />
            </div>
            <p className="text-3xl font-bold text-blue-600">₹{(totalBudget - totalSpent).toLocaleString()}</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-orange-500">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-600">Utilization</span>
              <DollarSign className="w-5 h-5 text-orange-600" />
            </div>
            <p className="text-3xl font-bold text-orange-600">{budgetUtilization.toFixed(1)}%</p>
          </CardContent>
        </Card>
      </div>

      {/* Create Event Form */}
      {showCreateEvent && (
        <Card className="border-t-4 border-t-[#90EE90]">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plus className="w-5 h-5 text-[#0A1F44]" />
              Create New Event
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreateEvent} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Event Name */}
                <div className="space-y-2">
                  <Label htmlFor="eventName">Event Name *</Label>
                  <Input
                    id="eventName"
                    value={eventName}
                    onChange={(e) => setEventName(e.target.value)}
                    placeholder="e.g., TechFest 2026"
                    required
                  />
                </div>

                {/* Duration */}
                <div className="space-y-2">
                  <Label htmlFor="duration">Duration *</Label>
                  <Select value={eventDuration} onValueChange={setEventDuration}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select duration" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 Day</SelectItem>
                      <SelectItem value="2">2 Days</SelectItem>
                      <SelectItem value="3">3 Days</SelectItem>
                      <SelectItem value="custom">Custom</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Date */}
                <div className="space-y-2">
                  <Label htmlFor="eventDate">Event Date *</Label>
                  <Input
                    id="eventDate"
                    type="date"
                    value={eventDate}
                    onChange={(e) => setEventDate(e.target.value)}
                    required
                  />
                </div>

                {/* Time */}
                <div className="space-y-2">
                  <Label htmlFor="eventTime">Event Time *</Label>
                  <Input
                    id="eventTime"
                    type="time"
                    value={eventTime}
                    onChange={(e) => setEventTime(e.target.value)}
                    required
                  />
                </div>

                {/* HOD */}
                <div className="space-y-2">
                  <Label htmlFor="hod">HOD Approval *</Label>
                  <Select value={eventHOD} onValueChange={setEventHOD}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select HOD" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hod_cse">Dr. Rajesh Kumar (CSE)</SelectItem>
                      <SelectItem value="hod_ece">Dr. Priya Sharma (ECE)</SelectItem>
                      <SelectItem value="hod_mech">Dr. Anand Singh (MECH)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Staff Coordinator */}
                <div className="space-y-2">
                  <Label htmlFor="staffCoordinator">Staff Coordinator *</Label>
                  <Select value={eventStaffCoordinator} onValueChange={setEventStaffCoordinator}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select staff coordinator" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="staff1">Prof. Kumar Reddy</SelectItem>
                      <SelectItem value="staff2">Prof. Meera Singh</SelectItem>
                      <SelectItem value="staff3">Prof. Anita Desai</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Venue */}
                <div className="space-y-2">
                  <Label htmlFor="venue">Venue *</Label>
                  <Select value={eventVenue} onValueChange={setEventVenue}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select venue" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auditorium">Main Auditorium</SelectItem>
                      <SelectItem value="open_air">Open Air Theatre</SelectItem>
                      <SelectItem value="seminar_hall">Seminar Hall</SelectItem>
                      <SelectItem value="lab301">Lab 301</SelectItem>
                      <SelectItem value="sports_ground">Sports Ground</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Budget */}
                <div className="space-y-2">
                  <Label htmlFor="budget">Budget Allocated (₹) *</Label>
                  <Input
                    id="budget"
                    type="number"
                    value={eventBudget}
                    onChange={(e) => setEventBudget(e.target.value)}
                    placeholder="150000"
                    required
                  />
                </div>
              </div>

              {/* Equipment Required */}
              <div className="space-y-2">
                <Label htmlFor="equipment">Equipment Required *</Label>
                <Textarea
                  id="equipment"
                  value={equipmentRequired}
                  onChange={(e) => setEquipmentRequired(e.target.value)}
                  placeholder="List all equipment needed: projectors, screens, chairs, tables, sound systems, etc."
                  rows={4}
                  required
                />
              </div>

              {/* Note about high budget */}
              {parseInt(eventBudget) > 100000 && (
                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <p className="text-sm text-yellow-800 font-semibold">
                    ⚠️ High Budget Event (&gt; ₹1L): Asset lifecycle tracking will be enabled
                  </p>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-3">
                <Button type="submit" className="bg-[#0A1F44] hover:bg-[#1a3a5c]">
                  Create Event
                </Button>
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => setShowCreateEvent(false)}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="events" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="events">My Events</TabsTrigger>
          <TabsTrigger value="assets">Asset Tracking</TabsTrigger>
          <TabsTrigger value="receipts">Financial Tracking</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        {/* MY EVENTS TAB */}
        <TabsContent value="events" className="space-y-4">
          {myEvents.map((event) => (
            <Card key={event.id} className="border-l-4 border-l-[#0A1F44]">
              <CardContent className="pt-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-[#0A1F44] mb-1">{event.name}</h3>
                    <div className="flex items-center gap-4 text-sm text-gray-600">
                      <span className="font-mono">{event.id}</span>
                      <span>•</span>
                      <span>{new Date(event.date).toLocaleDateString('en-IN')}</span>
                      <span>•</span>
                      <span>{event.venue}</span>
                    </div>
                  </div>
                  <Badge className="bg-green-500 text-white">{event.status}</Badge>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Budget Progress */}
                  <div>
                    <p className="text-sm font-semibold text-gray-700 mb-2">Budget Utilization</p>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Allocated</span>
                        <span className="font-bold">₹{event.budgetAllocated.toLocaleString()}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Spent</span>
                        <span className="font-bold text-green-600">₹{event.budgetSpent.toLocaleString()}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Remaining</span>
                        <span className="font-bold text-blue-600">
                          ₹{(event.budgetAllocated - event.budgetSpent).toLocaleString()}
                        </span>
                      </div>
                      <Progress 
                        value={(event.budgetSpent / event.budgetAllocated) * 100} 
                        className="h-2"
                      />
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-col gap-2">
                    <Button variant="outline" size="sm">
                      <Calendar className="w-4 h-4 mr-2" />
                      Edit Event Details
                    </Button>
                    <Button variant="outline" size="sm">
                      <Package className="w-4 h-4 mr-2" />
                      Manage Requirements
                    </Button>
                    <Button variant="outline" size="sm">
                      <Upload className="w-4 h-4 mr-2" />
                      Upload Receipt
                    </Button>
                    <Button variant="outline" size="sm">
                      <Download className="w-4 h-4 mr-2" />
                      Generate Report
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        {/* ASSET TRACKING TAB */}
        <TabsContent value="assets" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="w-5 h-5 text-[#0A1F44]" />
                Asset Lifecycle Tracking - TechFest 2026
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="text-left p-3">Asset Name</th>
                      <th className="text-center p-3">Required</th>
                      <th className="text-center p-3">Allocated</th>
                      <th className="text-center p-3">Status</th>
                      <th className="text-center p-3">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {assetRequirements.map((asset) => (
                      <tr key={asset.id} className="border-b hover:bg-gray-50">
                        <td className="p-3 font-semibold">{asset.name}</td>
                        <td className="p-3 text-center">{asset.quantity}</td>
                        <td className="p-3 text-center font-bold">{asset.allocated}</td>
                        <td className="p-3 text-center">
                          <Badge 
                            className={
                              asset.status === 'confirmed' 
                                ? 'bg-green-100 text-green-700' 
                                : 'bg-yellow-100 text-yellow-700'
                            }
                          >
                            {asset.status}
                          </Badge>
                        </td>
                        <td className="p-3 text-center">
                          {asset.status === 'pending' ? (
                            <Button size="sm" variant="outline">Request</Button>
                          ) : (
                            <Button size="sm" variant="ghost">View</Button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* RECEIPTS TAB */}
        <TabsContent value="receipts" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-[#0A1F44]" />
                  Financial Tracking - Receipts & Bills
                </CardTitle>
                <Button className="bg-[#0A1F44] hover:bg-[#1a3a5c]">
                  <Upload className="w-4 h-4 mr-2" />
                  Upload Receipt
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {receipts.map((receipt) => (
                  <div 
                    key={receipt.id}
                    className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:border-[#0A1F44] transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <FileText className="w-8 h-8 text-red-600" />
                      <div>
                        <p className="font-semibold">{receipt.name}</p>
                        <p className="text-sm text-gray-600">
                          {receipt.category} • {new Date(receipt.date).toLocaleDateString('en-IN')}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xl font-bold text-[#0A1F44]">₹{receipt.amount.toLocaleString()}</p>
                      <Button variant="outline" size="sm" className="mt-2">
                        <Download className="w-3 h-3 mr-1" />
                        Download
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* REPORTS TAB */}
        <TabsContent value="reports" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Download className="w-5 h-5 text-[#0A1F44]" />
                Generate Event Reports
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button variant="outline" className="h-24 flex flex-col gap-2">
                  <FileText className="w-8 h-8" />
                  <span>Budget Utilization Report</span>
                </Button>
                <Button variant="outline" className="h-24 flex flex-col gap-2">
                  <Package className="w-8 h-8" />
                  <span>Asset Allocation Report</span>
                </Button>
                <Button variant="outline" className="h-24 flex flex-col gap-2">
                  <DollarSign className="w-8 h-8" />
                  <span>Financial Summary</span>
                </Button>
                <Button variant="outline" className="h-24 flex flex-col gap-2">
                  <Calendar className="w-8 h-8" />
                  <span>Complete Event Report</span>
                </Button>
              </div>
              <div className="mt-6 p-4 bg-[#90EE90]/10 border border-[#90EE90] rounded-lg">
                <p className="text-sm text-gray-700">
                  <strong>📄 All reports will be generated as PDF</strong> with detailed breakdowns 
                  of budget, assets, and event timeline.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
