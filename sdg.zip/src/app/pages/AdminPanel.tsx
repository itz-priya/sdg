import { Settings, Users, Workflow, DollarSign, BarChart3, Link2, Shield, Database } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Switch } from '../components/ui/switch';
import { Badge } from '../components/ui/badge';

const users = [
  { id: 1, name: 'Dr. John Doe', email: 'john@cit.edu', role: 'HOD', department: 'CSE', status: 'active' },
  { id: 2, name: 'Prof. Sarah Smith', email: 'sarah@cit.edu', role: 'Faculty', department: 'CSE', status: 'active' },
  { id: 3, name: 'Mr. Kumar', email: 'kumar@cit.edu', role: 'Finance', department: 'Admin', status: 'active' },
  { id: 4, name: 'Student A', email: 'studenta@cit.edu', role: 'Student', department: 'CSE', status: 'active' },
];

const systemStats = [
  { label: 'Total Users', value: '234', icon: Users, color: 'text-blue-600' },
  { label: 'Active Sessions', value: '42', icon: Database, color: 'text-green-600' },
  { label: 'System Uptime', value: '99.8%', icon: BarChart3, color: 'text-[#0A1F44]' },
  { label: 'Storage Used', value: '47GB', icon: Database, color: 'text-orange-600' },
];

const workflowStages = [
  { name: 'Draft', threshold: 0, approvers: [], autoApprove: false },
  { name: 'HOD Approval', threshold: 50000, approvers: ['HOD'], autoApprove: false },
  { name: 'Finance Review', threshold: 100000, approvers: ['Finance Officer'], autoApprove: false },
  { name: 'Principal Approval', threshold: 200000, approvers: ['Principal'], autoApprove: false },
];

export default function AdminPanel() {
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#0A1F44]">Super Admin Dashboard</h1>
          <p className="text-gray-600 mt-1">System configuration and management</p>
        </div>
        <Badge className="bg-red-600 text-white px-3 py-1">
          <Shield className="w-4 h-4 mr-2" />
          Admin Access
        </Badge>
      </div>

      {/* System Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {systemStats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label}>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">{stat.label}</p>
                    <p className={`text-3xl font-bold ${stat.color}`}>{stat.value}</p>
                  </div>
                  <Icon className={`w-10 h-10 ${stat.color}`} />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Tabs defaultValue="users" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="users">
            <Users className="w-4 h-4 mr-2" />
            Users
          </TabsTrigger>
          <TabsTrigger value="workflow">
            <Workflow className="w-4 h-4 mr-2" />
            Workflow
          </TabsTrigger>
          <TabsTrigger value="budget">
            <DollarSign className="w-4 h-4 mr-2" />
            Budget
          </TabsTrigger>
          <TabsTrigger value="integrations">
            <Link2 className="w-4 h-4 mr-2" />
            Integrations
          </TabsTrigger>
          <TabsTrigger value="analytics">
            <BarChart3 className="w-4 h-4 mr-2" />
            Analytics
          </TabsTrigger>
        </TabsList>

        {/* User Management */}
        <TabsContent value="users" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-[#0A1F44]" />
                  User Management
                </CardTitle>
                <Button className="bg-[#0A1F44] hover:bg-[#1a3a5c]">
                  Add New User
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {/* Search and Filter */}
              <div className="flex gap-3 mb-6">
                <Input placeholder="Search users..." className="flex-1" />
                <Select defaultValue="all">
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Roles</SelectItem>
                    <SelectItem value="student">Student</SelectItem>
                    <SelectItem value="faculty">Faculty</SelectItem>
                    <SelectItem value="hod">HOD</SelectItem>
                    <SelectItem value="finance">Finance</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                    <SelectItem value="principal">Principal</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Users Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="text-left p-3">Name</th>
                      <th className="text-left p-3">Email</th>
                      <th className="text-left p-3">Role</th>
                      <th className="text-left p-3">Department</th>
                      <th className="text-center p-3">Status</th>
                      <th className="text-center p-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((user) => (
                      <tr key={user.id} className="border-b hover:bg-gray-50">
                        <td className="p-3 font-semibold">{user.name}</td>
                        <td className="p-3 text-gray-600">{user.email}</td>
                        <td className="p-3">
                          <Badge variant="outline">{user.role}</Badge>
                        </td>
                        <td className="p-3">{user.department}</td>
                        <td className="p-3 text-center">
                          <Badge className="bg-green-100 text-green-700">
                            {user.status}
                          </Badge>
                        </td>
                        <td className="p-3">
                          <div className="flex gap-2 justify-center">
                            <Button variant="outline" size="sm">Edit</Button>
                            <Button variant="outline" size="sm">Disable</Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* Role Permissions */}
          <Card>
            <CardHeader>
              <CardTitle>Role Permissions Matrix</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="text-left p-3">Permission</th>
                      <th className="text-center p-3">Student</th>
                      <th className="text-center p-3">Faculty</th>
                      <th className="text-center p-3">HOD</th>
                      <th className="text-center p-3">Finance</th>
                      <th className="text-center p-3">Principal</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b">
                      <td className="p-3">View Budget</td>
                      <td className="text-center">❌</td>
                      <td className="text-center">✅</td>
                      <td className="text-center">✅</td>
                      <td className="text-center">✅</td>
                      <td className="text-center">✅</td>
                    </tr>
                    <tr className="border-b">
                      <td className="p-3">Create Request</td>
                      <td className="text-center">✅</td>
                      <td className="text-center">✅</td>
                      <td className="text-center">✅</td>
                      <td className="text-center">✅</td>
                      <td className="text-center">✅</td>
                    </tr>
                    <tr className="border-b">
                      <td className="p-3">Approve Requests</td>
                      <td className="text-center">❌</td>
                      <td className="text-center">❌</td>
                      <td className="text-center">✅</td>
                      <td className="text-center">✅</td>
                      <td className="text-center">✅</td>
                    </tr>
                    <tr className="border-b">
                      <td className="p-3">Budget Allocation</td>
                      <td className="text-center">❌</td>
                      <td className="text-center">❌</td>
                      <td className="text-center">✅</td>
                      <td className="text-center">✅</td>
                      <td className="text-center">✅</td>
                    </tr>
                    <tr className="border-b">
                      <td className="p-3">Generate Reports</td>
                      <td className="text-center">❌</td>
                      <td className="text-center">✅</td>
                      <td className="text-center">✅</td>
                      <td className="text-center">✅</td>
                      <td className="text-center">✅</td>
                    </tr>
                    <tr className="border-b">
                      <td className="p-3">System Admin</td>
                      <td className="text-center">❌</td>
                      <td className="text-center">❌</td>
                      <td className="text-center">❌</td>
                      <td className="text-center">❌</td>
                      <td className="text-center">✅</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Workflow Configuration */}
        <TabsContent value="workflow" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Workflow className="w-5 h-5 text-[#0A1F44]" />
                Approval Workflow Configuration
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Workflow Stages */}
                {workflowStages.map((stage, index) => (
                  <div key={index} className="p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-[#0A1F44] text-white rounded-full flex items-center justify-center font-bold">
                          {index + 1}
                        </div>
                        <h4 className="font-semibold text-lg">{stage.name}</h4>
                      </div>
                      <Button variant="outline" size="sm">Edit Stage</Button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label className="text-sm text-gray-600">Amount Threshold</Label>
                        <Input
                          type="number"
                          defaultValue={stage.threshold}
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label className="text-sm text-gray-600">Approvers</Label>
                        <Select defaultValue={stage.approvers[0] || 'none'}>
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">None</SelectItem>
                            <SelectItem value="HOD">HOD</SelectItem>
                            <SelectItem value="Finance Officer">Finance Officer</SelectItem>
                            <SelectItem value="Principal">Principal</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="flex items-center gap-2 mt-6">
                        <Switch id={`auto-${index}`} checked={stage.autoApprove} />
                        <Label htmlFor={`auto-${index}`} className="text-sm">
                          Auto-approve if conditions met
                        </Label>
                      </div>
                    </div>
                  </div>
                ))}

                <Button className="w-full bg-[#90EE90] text-[#0A1F44] hover:bg-[#90EE90]/80">
                  Add New Stage
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Notification Settings */}
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Email Notifications</p>
                    <p className="text-sm text-gray-600">Send email alerts for approvals</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">SMS Alerts</p>
                    <p className="text-sm text-gray-600">High-priority requests only</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Deadline Reminders</p>
                    <p className="text-sm text-gray-600">24h before approval deadline</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Escalation Alerts</p>
                    <p className="text-sm text-gray-600">Notify higher authority on delays</p>
                  </div>
                  <Switch />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Budget Allocation */}
        <TabsContent value="budget" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-[#0A1F44]" />
                Department Budget Allocation - FY 2025-26
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {['CSE', 'MECH', 'CIVIL', 'ECE', 'EEE'].map((dept) => (
                  <div key={dept} className="p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-semibold text-lg">{dept} Department</h4>
                      <Button variant="outline" size="sm">Reallocate</Button>
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <Label className="text-sm text-gray-600">Total Budget (₹)</Label>
                        <Input
                          type="number"
                          defaultValue={dept === 'CSE' ? 500000 : dept === 'MECH' ? 450000 : 350000}
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label className="text-sm text-gray-600">Equipment</Label>
                        <Input type="number" defaultValue="200000" className="mt-1" />
                      </div>
                      <div>
                        <Label className="text-sm text-gray-600">Consumables</Label>
                        <Input type="number" defaultValue="100000" className="mt-1" />
                      </div>
                    </div>
                  </div>
                ))}

                <div className="p-4 bg-[#0A1F44] text-white rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm opacity-80">Total Campus Budget</p>
                      <p className="text-3xl font-bold">₹20,00,000</p>
                    </div>
                    <Button className="bg-white text-[#0A1F44] hover:bg-gray-100">
                      Save Changes
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Integrations */}
        <TabsContent value="integrations" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Link2 className="w-5 h-5 text-[#0A1F44]" />
                External System Integrations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Tally Integration */}
                <div className="p-4 border border-gray-200 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                        <Database className="w-6 h-6 text-orange-600" />
                      </div>
                      <div>
                        <h4 className="font-semibold">Tally ERP</h4>
                        <p className="text-sm text-gray-600">Accounting integration</p>
                      </div>
                    </div>
                    <Badge className="bg-green-100 text-green-700">Connected</Badge>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">Configure</Button>
                    <Button variant="outline" size="sm">Test Connection</Button>
                    <Button variant="outline" size="sm" className="text-red-600">Disconnect</Button>
                  </div>
                </div>

                {/* ERP Integration */}
                <div className="p-4 border border-gray-200 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <Settings className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <h4 className="font-semibold">Campus ERP</h4>
                        <p className="text-sm text-gray-600">Student & HR management</p>
                      </div>
                    </div>
                    <Badge className="bg-gray-100 text-gray-700">Not Connected</Badge>
                  </div>
                  <Button variant="outline" size="sm">Setup Integration</Button>
                </div>

                {/* Payment Gateway */}
                <div className="p-4 border border-gray-200 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <DollarSign className="w-6 h-6 text-green-600" />
                      </div>
                      <div>
                        <h4 className="font-semibold">Payment Gateway</h4>
                        <p className="text-sm text-gray-600">Online payments</p>
                      </div>
                    </div>
                    <Badge className="bg-green-100 text-green-700">Connected</Badge>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">Configure</Button>
                    <Button variant="outline" size="sm">View Logs</Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* System Analytics */}
        <TabsContent value="analytics" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-[#0A1F44]" />
                System Usage Analytics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Usage Stats */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-600">Daily Active Users</p>
                    <p className="text-2xl font-bold text-[#0A1F44]">156</p>
                    <p className="text-xs text-green-600 mt-1">↑ 12% vs last week</p>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-600">Requests Processed</p>
                    <p className="text-2xl font-bold text-[#0A1F44]">1,234</p>
                    <p className="text-xs text-green-600 mt-1">This month</p>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-600">Avg Response Time</p>
                    <p className="text-2xl font-bold text-[#0A1F44]">1.2s</p>
                    <p className="text-xs text-green-600 mt-1">System performance</p>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-600">Error Rate</p>
                    <p className="text-2xl font-bold text-[#0A1F44]">0.02%</p>
                    <p className="text-xs text-green-600 mt-1">Very low</p>
                  </div>
                </div>

                {/* Activity Log */}
                <div>
                  <h4 className="font-semibold mb-3">Recent System Activity</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                      <span>User login: john@cit.edu</span>
                      <span className="text-gray-500">2 minutes ago</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                      <span>Budget allocation updated: CSE Dept</span>
                      <span className="text-gray-500">15 minutes ago</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                      <span>Report generated: Executive Summary</span>
                      <span className="text-gray-500">1 hour ago</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                      <span>Approval completed: REQ-456</span>
                      <span className="text-gray-500">2 hours ago</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
