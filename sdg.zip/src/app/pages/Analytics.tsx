import { BarChart3, TrendingUp, AlertTriangle, PieChart, DollarSign, Calendar } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import {
  BarChart,
  Bar,
  PieChart as RechartsPie,
  Pie,
  Cell,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from 'recharts';

const budgetUtilization = [
  { dept: 'CSE', utilized: 78, budget: 500000, spent: 390000 },
  { dept: 'MECH', utilized: 92, budget: 450000, spent: 414000 },
  { dept: 'CIVIL', utilized: 65, budget: 350000, spent: 227500 },
  { dept: 'ECE', utilized: 71, budget: 400000, spent: 284000 },
  { dept: 'EEE', utilized: 58, budget: 300000, spent: 174000 },
];

const monthlyTrend = [
  { month: 'Aug', CSE: 45, MECH: 52, CIVIL: 30, ECE: 38, EEE: 25 },
  { month: 'Sep', CSE: 62, MECH: 58, CIVIL: 35, ECE: 42, EEE: 28 },
  { month: 'Oct', CSE: 48, MECH: 65, CIVIL: 40, ECE: 45, EEE: 32 },
  { month: 'Nov', CSE: 75, MECH: 72, CIVIL: 45, ECE: 51, EEE: 35 },
  { month: 'Dec', CSE: 58, MECH: 85, CIVIL: 38, ECE: 48, EEE: 30 },
  { month: 'Jan', CSE: 82, MECH: 95, CIVIL: 42, ECE: 55, EEE: 38 },
];

const categoryBreakdown = [
  { name: 'Equipment', value: 1250000, color: '#0A1F44' },
  { name: 'Software', value: 580000, color: '#1a3a5c' },
  { name: 'Consumables', value: 320000, color: '#90EE90' },
  { name: 'Events', value: 180000, color: '#FFD700' },
  { name: 'Travel', value: 150000, color: '#FF6B6B' },
];

const vendorAnalysis = [
  { name: 'Dell India', amount: 450000, transactions: 12 },
  { name: 'HP Enterprise', amount: 380000, transactions: 8 },
  { name: 'Microsoft', amount: 320000, transactions: 15 },
  { name: 'Cisco Systems', amount: 280000, transactions: 6 },
  { name: 'Others', amount: 570000, transactions: 25 },
];

const performanceMetrics = [
  { metric: 'Budget Efficiency', value: 85, fullMark: 100 },
  { metric: 'Approval Speed', value: 72, fullMark: 100 },
  { metric: 'Compliance', value: 95, fullMark: 100 },
  { metric: 'Asset Utilization', value: 78, fullMark: 100 },
  { metric: 'Cost Savings', value: 68, fullMark: 100 },
];

const COLORS = ['#0A1F44', '#1a3a5c', '#90EE90', '#FFD700', '#FF6B6B'];

export default function Analytics() {
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#0A1F44]">Real-Time Analytics Dashboard</h1>
          <p className="text-gray-600 mt-1">Campus Financial Intelligence & Insights</p>
        </div>
        <div className="flex items-center gap-3">
          <Select defaultValue="fy2025">
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="fy2025">FY 2025-26</SelectItem>
              <SelectItem value="fy2024">FY 2024-25</SelectItem>
              <SelectItem value="fy2023">FY 2023-24</SelectItem>
            </SelectContent>
          </Select>
          <Select defaultValue="all">
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Departments</SelectItem>
              <SelectItem value="cse">CSE</SelectItem>
              <SelectItem value="mech">MECH</SelectItem>
              <SelectItem value="civil">CIVIL</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-t-4 border-t-[#0A1F44]">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-600">Overall Utilization</span>
              <BarChart3 className="w-5 h-5 text-[#0A1F44]" />
            </div>
            <p className="text-3xl font-bold text-[#0A1F44]">68%</p>
            <div className="flex items-center gap-2 mt-2">
              <TrendingUp className="w-4 h-4 text-green-600" />
              <span className="text-sm text-green-600">+5% from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-t-4 border-t-yellow-500">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-600">Risk Alerts</span>
              <AlertTriangle className="w-5 h-5 text-yellow-600" />
            </div>
            <p className="text-3xl font-bold text-yellow-600">3</p>
            <p className="text-sm text-gray-600 mt-2">2 Overspend, 1 Low Balance</p>
          </CardContent>
        </Card>

        <Card className="border-t-4 border-t-green-500">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-600">Total Budget</span>
              <DollarSign className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-3xl font-bold text-[#0A1F44]">₹20L</p>
            <p className="text-sm text-gray-600 mt-2">Across 5 departments</p>
          </CardContent>
        </Card>

        <Card className="border-t-4 border-t-blue-500">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-600">Avg Approval Time</span>
              <Calendar className="w-5 h-5 text-blue-600" />
            </div>
            <p className="text-3xl font-bold text-[#0A1F44]">2.3d</p>
            <p className="text-sm text-gray-600 mt-2">Down from 3.5 days</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="budget" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="budget">Budget Analysis</TabsTrigger>
          <TabsTrigger value="spending">Spending Patterns</TabsTrigger>
          <TabsTrigger value="vendors">Vendor Insights</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>

        {/* Budget Analysis */}
        <TabsContent value="budget" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Budget Utilization Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-[#0A1F44]" />
                  Department-wise Budget Utilization
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={350}>
                  <BarChart data={budgetUtilization}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="dept" />
                    <YAxis />
                    <Tooltip 
                      formatter={(value: any, name: string) => {
                        if (name === 'utilized') return `${value}%`;
                        return `₹${value.toLocaleString()}`;
                      }}
                    />
                    <Legend />
                    <Bar dataKey="utilized" fill="#0A1F44" name="Utilization %" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Donut Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="w-5 h-5 text-[#0A1F44]" />
                  Category-wise Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={350}>
                  <RechartsPie>
                    <Pie
                      data={categoryBreakdown}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={120}
                      paddingAngle={5}
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {categoryBreakdown.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value: any) => `₹${value.toLocaleString()}`} />
                  </RechartsPie>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Risk Alerts */}
          <Card className="border-l-4 border-l-red-500">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-red-600" />
                Risk Alerts & Recommendations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <p className="font-semibold text-red-800">🔴 MECH Department - Overspend Risk</p>
                    <span className="text-2xl font-bold text-red-600">92%</span>
                  </div>
                  <p className="text-sm text-red-700">Budget: ₹4.5L | Spent: ₹4.14L | Remaining: ₹36K</p>
                  <p className="text-sm text-gray-700 mt-2">
                    <strong>Recommendation:</strong> Suspend non-critical procurement until next quarter
                  </p>
                </div>

                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <p className="font-semibold text-yellow-800">🟡 CSE Department - Low Balance Warning</p>
                    <span className="text-2xl font-bold text-yellow-600">₹27.5K</span>
                  </div>
                  <p className="text-sm text-yellow-700">Budget: ₹5L | Utilized: 78% | Available: ₹27.5K</p>
                  <p className="text-sm text-gray-700 mt-2">
                    <strong>Recommendation:</strong> Consider budget reallocation from underutilized departments
                  </p>
                </div>

                <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <p className="font-semibold text-green-800">🟢 EEE Department - Underutilized Budget</p>
                    <span className="text-2xl font-bold text-green-600">58%</span>
                  </div>
                  <p className="text-sm text-green-700">Budget: ₹3L | Spent: ₹1.74L | Available: ₹1.26L</p>
                  <p className="text-sm text-gray-700 mt-2">
                    <strong>Opportunity:</strong> Surplus budget available for strategic initiatives
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Spending Patterns */}
        <TabsContent value="spending" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-[#0A1F44]" />
                Monthly Spending Trends by Department
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={monthlyTrend}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis label={{ value: 'Amount (₹K)', angle: -90, position: 'insideLeft' }} />
                  <Tooltip formatter={(value) => `₹${value}K`} />
                  <Legend />
                  <Line type="monotone" dataKey="CSE" stroke="#0A1F44" strokeWidth={2} />
                  <Line type="monotone" dataKey="MECH" stroke="#FF6B6B" strokeWidth={2} />
                  <Line type="monotone" dataKey="CIVIL" stroke="#90EE90" strokeWidth={2} />
                  <Line type="monotone" dataKey="ECE" stroke="#FFD700" strokeWidth={2} />
                  <Line type="monotone" dataKey="EEE" stroke="#1a3a5c" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Top Spending Departments */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {budgetUtilization.sort((a, b) => b.spent - a.spent).slice(0, 3).map((dept, index) => (
              <Card key={dept.dept}>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-3xl font-bold">#{index + 1}</span>
                    <span className="text-2xl font-bold text-[#0A1F44]">{dept.dept}</span>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Total Spent</span>
                      <span className="font-bold">₹{(dept.spent / 1000).toFixed(1)}K</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Budget</span>
                      <span className="font-bold">₹{(dept.budget / 1000).toFixed(1)}K</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Utilization</span>
                      <span className={`font-bold ${dept.utilized > 90 ? 'text-red-600' : dept.utilized > 75 ? 'text-yellow-600' : 'text-green-600'}`}>
                        {dept.utilized}%
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Vendor Analysis */}
        <TabsContent value="vendors" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PieChart className="w-5 h-5 text-[#0A1F44]" />
                Top Vendors by Transaction Volume
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={vendorAnalysis} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis dataKey="name" type="category" width={120} />
                  <Tooltip formatter={(value) => `₹${Number(value).toLocaleString()}`} />
                  <Bar dataKey="amount" fill="#0A1F44" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Vendor Details Table */}
          <Card>
            <CardHeader>
              <CardTitle>Vendor Transaction Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="text-left p-3">Vendor Name</th>
                      <th className="text-right p-3">Total Amount</th>
                      <th className="text-right p-3">Transactions</th>
                      <th className="text-right p-3">Avg per Transaction</th>
                      <th className="text-center p-3">Rating</th>
                    </tr>
                  </thead>
                  <tbody>
                    {vendorAnalysis.map((vendor) => (
                      <tr key={vendor.name} className="border-b hover:bg-gray-50">
                        <td className="p-3 font-semibold">{vendor.name}</td>
                        <td className="p-3 text-right font-bold">₹{vendor.amount.toLocaleString()}</td>
                        <td className="p-3 text-right">{vendor.transactions}</td>
                        <td className="p-3 text-right">₹{Math.round(vendor.amount / vendor.transactions).toLocaleString()}</td>
                        <td className="p-3 text-center">
                          <span className="text-yellow-500">★★★★☆</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Performance Metrics */}
        <TabsContent value="performance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-[#0A1F44]" />
                System Performance Metrics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <RadarChart data={performanceMetrics}>
                  <PolarGrid />
                  <PolarAngleAxis dataKey="metric" />
                  <PolarRadiusAxis angle={90} domain={[0, 100]} />
                  <Radar name="Performance" dataKey="value" stroke="#0A1F44" fill="#90EE90" fillOpacity={0.6} />
                  <Tooltip />
                </RadarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Performance Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {performanceMetrics.map((metric) => (
              <Card key={metric.metric}>
                <CardContent className="pt-6">
                  <p className="text-sm text-gray-600 mb-2">{metric.metric}</p>
                  <div className="flex items-baseline gap-2 mb-2">
                    <span className="text-3xl font-bold text-[#0A1F44]">{metric.value}</span>
                    <span className="text-gray-500">/100</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full ${
                        metric.value >= 80 ? 'bg-green-500' : metric.value >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                      }`}
                      style={{ width: `${metric.value}%` }}
                    ></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
