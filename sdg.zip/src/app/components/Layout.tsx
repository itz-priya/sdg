import { Outlet, useNavigate, useLocation } from 'react-router';
import { useState } from 'react';
import {
  LayoutDashboard,
  Wallet,
  ShoppingCart,
  Package,
  CheckCircle,
  BarChart3,
  FileText,
  Settings,
  LogOut,
  Menu,
  X,
  Bell,
  Search,
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import logoImage from 'figma:asset/019fea43cd48134f3e507bb71f3a1e982f09571c.png';
import NotificationCenter from './NotificationCenter';

const menuItems = [
  { path: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { path: '/budget', icon: Wallet, label: 'Budget Wallet' },
  { path: '/procurement', icon: ShoppingCart, label: 'Procurement' },
  { path: '/assets', icon: Package, label: 'Asset Tracker' },
  { path: '/approvals', icon: CheckCircle, label: 'Approvals' },
  { path: '/analytics', icon: BarChart3, label: 'Analytics' },
  { path: '/reports', icon: FileText, label: 'Reports' },
  { path: '/admin', icon: Settings, label: 'Admin Panel' },
];

export default function Layout() {
  const navigate = useNavigate();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    navigate('/');
  };

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Navigation Bar */}
      <header className="bg-[#0A1F44] text-white shadow-lg sticky top-0 z-50">
        <div className="flex items-center justify-between px-4 py-3">
          {/* Logo and Title */}
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden p-2 hover:bg-white/10 rounded-lg"
            >
              <Menu className="w-5 h-5" />
            </button>
            <img src={logoImage} alt="CIT Logo" className="h-10 object-contain" />
            <div className="hidden md:block">
              <h1 className="text-lg font-bold">CAMPUSFIN PORTAL</h1>
              <p className="text-xs text-[#90EE90]">Financial Command Center</p>
            </div>
          </div>

          {/* Search and Actions */}
          <div className="flex items-center gap-3">
            <div className="hidden md:flex items-center gap-2 bg-white/10 rounded-lg px-3 py-2 min-w-[300px]">
              <Search className="w-4 h-4 text-gray-300" />
              <Input
                placeholder='Search "Laptop procurement CSE"...'
                className="bg-transparent border-0 text-white placeholder:text-gray-300 focus-visible:ring-0 p-0 h-auto"
              />
            </div>
            <NotificationCenter />
            <Button
              onClick={handleLogout}
              variant="ghost"
              className="text-white hover:bg-white/10"
              size="sm"
            >
              <LogOut className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Logout</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar Navigation */}
        <aside
          className={`
          fixed lg:sticky top-[64px] left-0 h-[calc(100vh-64px)] bg-white border-r border-gray-200 
          transition-all duration-300 z-40
          ${sidebarOpen ? 'w-64' : 'w-0 lg:w-16'}
          ${mobileMenuOpen ? 'block' : 'hidden lg:block'}
        `}
        >
          <nav className="p-4 space-y-2">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const active = isActive(item.path);
              return (
                <button
                  key={item.path}
                  onClick={() => {
                    navigate(item.path);
                    setMobileMenuOpen(false);
                  }}
                  className={`
                    w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all
                    ${active 
                      ? 'bg-[#0A1F44] text-white shadow-lg' 
                      : 'text-gray-700 hover:bg-gray-100'
                    }
                  `}
                >
                  <Icon className="w-5 h-5 flex-shrink-0" />
                  {sidebarOpen && <span className="font-medium">{item.label}</span>}
                </button>
              );
            })}
          </nav>

          {/* User Profile Card */}
          {sidebarOpen && (
            <div className="absolute bottom-4 left-4 right-4 bg-gradient-to-r from-[#0A1F44] to-[#1a3a5c] text-white rounded-lg p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#90EE90] rounded-full flex items-center justify-center text-[#0A1F44] font-bold">
                  HD
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm truncate">HOD - CSE</p>
                  <p className="text-xs text-[#90EE90] truncate">Dr. John Doe</p>
                </div>
              </div>
            </div>
          )}
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6 min-h-[calc(100vh-64px)] overflow-auto">
          <Outlet />
        </main>
      </div>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}
    </div>
  );
}