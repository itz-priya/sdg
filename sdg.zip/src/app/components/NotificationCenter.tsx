import { Bell } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from './ui/popover';
import { ScrollArea } from './ui/scroll-area';

const notifications = [
  {
    id: 1,
    title: 'CSE Budget Low',
    message: 'CSE department budget below ₹50K threshold',
    time: '5 minutes ago',
    type: 'warning',
    read: false,
  },
  {
    id: 2,
    title: 'Request Approved',
    message: 'REQ-123 approved by HOD',
    time: '1 hour ago',
    type: 'success',
    read: false,
  },
  {
    id: 3,
    title: 'Pending Approval',
    message: '2 procurement requests need your review',
    time: '2 hours ago',
    type: 'info',
    read: true,
  },
  {
    id: 4,
    title: 'Maintenance Due',
    message: 'Asset CST-045 maintenance scheduled tomorrow',
    time: '1 day ago',
    type: 'info',
    read: true,
  },
];

export default function NotificationCenter() {
  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="relative">
          <Bell className="w-5 h-5" />
          {unreadCount > 0 && (
            <Badge className="absolute -top-1 -right-1 w-5 h-5 p-0 flex items-center justify-center bg-red-500 text-white text-xs">
              {unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80" align="end">
        <div className="space-y-2">
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-semibold text-[#0A1F44]">Notifications</h4>
            <Button variant="ghost" size="sm" className="text-xs">
              Mark all read
            </Button>
          </div>
          
          <ScrollArea className="h-96">
            <div className="space-y-2">
              {notifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                    notification.read
                      ? 'bg-white border-gray-200'
                      : 'bg-[#90EE90]/10 border-[#90EE90]'
                  } hover:border-[#0A1F44]`}
                >
                  <div className="flex items-start gap-2">
                    {!notification.read && (
                      <div className="w-2 h-2 bg-[#90EE90] rounded-full mt-1.5 flex-shrink-0" />
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm text-[#0A1F44]">
                        {notification.title}
                      </p>
                      <p className="text-sm text-gray-600 mt-1">
                        {notification.message}
                      </p>
                      <p className="text-xs text-gray-500 mt-2">
                        {notification.time}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>

          <div className="pt-2 border-t">
            <Button variant="outline" className="w-full text-sm">
              View All Notifications
            </Button>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}
