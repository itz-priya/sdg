# CAMPUSFIN Portal - Role-Based Event Management System

## 🎓 Chennai Institute of Technology - Event & Financial Management

### ✅ Complete Role-Based Implementation

The system now features **distinct interfaces for each user role** with event management as the core focus.

---

## 🔐 Login & Registration System

### Sign In
- **7 User Roles**:
  - Student
  - Student Coordinator
  - Faculty
  - Staff Coordinator
  - HOD (Head of Department)
  - Principal
  - Administrator

### Sign Up

#### Student Registration Form:
- Full Name
- Register Number (e.g., 2021CSE001)
- Email
- Phone Number
- Department (CSE/ECE/EEE/MECH/CIVIL)
- Batch/Year (2021-2025, 2022-2026, etc.)
- Password

#### Staff/Faculty/Admin Registration Form:
- Role Selection (Faculty/Staff Coordinator/HOD/Admin/Principal)
- Full Name
- Email
- Phone Number
- Department
- Password

---

## 👨‍🎓 STUDENT PORTAL (`/student/events`)

### Event Discovery Hub

**Features:**
- **Event Cards** with:
  - Event posters (dynamic images)
  - Event type badges (Technical/Cultural/Sports/Workshop/Seminar/Exhibition)
  - Event name and description
  - Tags (AI, ML, Coding, Dance, etc.)
  - Date, time, and venue information
  - Student coordinator name

- **Seat Availability**:
  - Progress bar showing seats booked vs total
  - Color-coded: Green (<90%), Red (>90%)
  - Real-time seat count

- **Registration Deadline**:
  - Days remaining counter
  - Color-coded urgency:
    - Green: >5 days
    - Orange: 2-5 days
    - Red: <2 days
  - "Registration Closed" indicator

- **Smart Filtering**:
  - Search by event name/description
  - Filter by Type (Technical/Cultural/Sports/Workshop/Seminar/Exhibition)
  - Filter by Category (Fest/Event/Workshop/Sports/Seminar/Expo)
  - Filter by Department (CSE/ECE/EEE/MECH/CIVIL/Arts/Management)

- **Registration**:
  - "Register Now" button with link
  - Disabled when deadline passed or seats full
  - "View Details" button for more information

- **Stats Dashboard**:
  - Total events available
  - Open for registration count
  - Urgent events (deadline <3 days)
  - My registrations count

---

## 👥 STUDENT COORDINATOR PORTAL (`/coordinator/dashboard`)

### Event Creation & Management

**Features:**

#### 1. **Create New Event Form**
- Event Name
- Duration (1/2/3 days or custom)
- Event Date (date picker)
- Event Time (time picker)
- HOD Approval (dropdown selection)
- Staff Coordinator (dropdown selection)
- Venue (dropdown: Auditorium/Open Air Theatre/Seminar Hall/Lab/Sports Ground)
- Budget Allocated (₹)
- Equipment Required (textarea)

**Special Features:**
- Events with budget >₹1L automatically get asset lifecycle tracking enabled
- Form is editable after creation
- All fields validated before submission

#### 2. **Budget Tracking Dashboard**
- Total Budget Allocated
- Budget Spent (with receipts)
- Remaining Budget
- Utilization Percentage
- Visual progress bars

#### 3. **My Events Tab**
Shows all events managed by the coordinator:
- Event details card
- Budget utilization visualization
- Quick action buttons:
  - Edit Event Details
  - Manage Requirements
  - Upload Receipt
  - Generate Report

#### 4. **Asset Lifecycle Tracking Tab**
Complete tracking of event assets:

| Asset | Required | Allocated | Status |
|-------|----------|-----------|--------|
| Chairs | 500 | 500 | ✅ Confirmed |
| Tables | 50 | 50 | ✅ Confirmed |
| Projectors | 3 | 2 | ⏳ Pending |
| Screens | 3 | 2 | ⏳ Pending |
| Sound System | 1 | 1 | ✅ Confirmed |
| Microphones | 5 | 5 | ✅ Confirmed |
| Consoles | 2 | 0 | ⏳ Pending |
| Lab Computers | 30 | 30 | ✅ Confirmed |

Actions:
- Request pending assets
- View allocation details
- Track asset condition

#### 5. **Financial Tracking - Receipts Tab**
- Upload receipts/bills (PDF, JPG, PNG)
- Receipt preview with details:
  - File name
  - Upload date
  - Amount
  - Category (Printing/Catering/Equipment/etc.)
- Download receipts
- Automatic budget calculation from receipts

#### 6. **Reports Generation Tab**
Generate PDF reports:
- Budget Utilization Report
- Asset Allocation Report
- Financial Summary
- Complete Event Report

---

## 👔 STAFF COORDINATOR PORTAL (`/staff/events`)

### Comprehensive Event Oversight

**Features:**

#### 1. **Event List**
View all events across departments:
- Event details (name, date, venue, budget)
- Student coordinator assigned
- Event status (Active/Planning/Completed)
- Quick actions:
  - View Details
  - Track Assets
  - Generate Report (PDF)

#### 2. **Student Coordinators Management**

**View All Coordinators:**
| Name | Register No | Department | Events Assigned | Status | Actions |
|------|-------------|------------|-----------------|--------|---------|
| Rahul Kumar | 2021CSE045 | CSE | EVT-001 | Active | Edit/Revoke |
| Priya Sharma | 2021CSE062 | CSE | EVT-003 | Active | Edit/Revoke |
| Ankit Verma | 2021CSE089 | CSE | EVT-006 | Active | Edit/Revoke |

**Add New Coordinator:**
- Student Name
- Register Number
- Department
- Assign to Event
- Actions: Add or Revoke access

#### 3. **Asset Lifecycle Tracking**

Complete oversight of all event assets:
- View assets by event
- Track allocation status
- Monitor return status
- Check asset condition (Good/Damaged/Pending)
- Update asset status

#### 4. **Procurement Management**

**Procurement Items:**
- Item name and description
- Associated event
- Quantity required
- Amount (₹)
- Vendor information
- Status (Approved/Pending)

**Actions:**
- Approve procurement requests
- Reject with reason
- View vendor details

#### 5. **PDF Report Generation**
Generate comprehensive reports:
- All Events Report
- Coordinators Report
- Asset Utilization Report
- Procurement Summary
- Financial Overview
- Complete Report (all data)

---

## 📊 HOD PORTAL (Uses existing Dashboard/Budget/Approvals)

- View department-wise budget utilization
- Approve high-value procurement (>₹50K)
- Budget reallocation
- Department analytics

---

## 🎓 PRINCIPAL PORTAL (Uses Analytics/Reports)

- Campus-wide analytics
- Cross-department comparison
- Strategic decision reports
- Complete financial oversight

---

## 🔧 ADMIN PORTAL (Uses existing Admin Panel)

- User management
- System configuration
- Integration settings
- System analytics

---

## 🎨 Design & UX Features

### Color Scheme
- **Primary**: Navy Blue (#0A1F44) - Institutional trust
- **Accent**: Pastel Green (#90EE90) - Modern appeal
- **Status Colors**:
  - Green: Active/Approved/Confirmed
  - Yellow: Pending/Warning
  - Red: Urgent/Rejected/Closed
  - Blue: Info/Allocated

### Responsive Design
- Mobile-first approach
- Card-based layouts
- Touch-friendly buttons
- Collapsible sections
- Progressive disclosure

### Interactive Elements
- Real-time seat availability
- Countdown timers for deadlines
- Progress bars for budget utilization
- Badge indicators for status
- Hover effects and transitions

---

## 🔄 Complete Workflow

### Event Lifecycle

1. **Student Coordinator Creates Event**
   - Fills event creation form
   - Specifies budget, venue, equipment
   - Submits for approval

2. **HOD Approval**
   - Reviews event details
   - Approves/rejects with comments

3. **Staff Coordinator Oversight**
   - Assigns student coordinators
   - Manages asset allocation
   - Approves procurement

4. **Asset Tracking**
   - Equipment allocated
   - Condition monitored
   - Return tracked

5. **Financial Tracking**
   - Receipts uploaded
   - Budget tracked in real-time
   - Reports generated

6. **Student Registration**
   - Students discover events
   - Register through portal
   - Receive confirmation

7. **Event Completion**
   - Final reports generated
   - Assets returned and verified
   - Budget closure

---

## 📱 Key Differentiators

### ✅ True Role-Based Access
- Each role has **distinct interface**
- No generic dashboard shown to all
- Customized navigation per role
- Role-specific data and actions

### ✅ Event-Centric Design
- Events are the primary entity
- Budget tied to events
- Assets linked to events
- Reports generated per event

### ✅ Asset Lifecycle Management
- Track from allocation to return
- Monitor condition
- Ensure accountability
- Generate utilization reports

### ✅ Financial Transparency
- Receipt upload mandatory
- Real-time budget tracking
- Automatic calculations
- Audit trail maintained

### ✅ PDF Report Generation
- All reports exportable as PDF
- Multiple report types
- Event-wise and consolidated
- Ready for printing/sharing

---

## 🚀 Technical Stack

- **Frontend**: React 18 + TypeScript
- **Routing**: React Router (role-based routes)
- **UI**: shadcn/ui + Tailwind CSS v4
- **Charts**: Recharts
- **Icons**: Lucide React
- **Forms**: React Hook Form
- **File Upload**: Native HTML5
- **Responsive**: Mobile-first design

---

## 📋 Complete Route Structure

```
/ (Login)
│
├── /student/events (Student Portal)
│
├── /coordinator/dashboard (Student Coordinator)
│
├── /staff/events (Staff Coordinator)
│
├── /hod/dashboard (HOD Dashboard)
├── /hod/budget (HOD Budget Management)
├── /hod/approvals (HOD Approvals)
│
├── /principal/dashboard (Principal Analytics)
├── /principal/reports (Principal Reports)
│
└── /admin (Admin Panel)
```

---

## ✨ Summary

The CAMPUSFIN Portal is now a **complete event management system** with:

✅ **Sign In + Sign Up** functionality for all roles  
✅ **Student Portal** - Event discovery with registration  
✅ **Student Coordinator** - Event creation & management  
✅ **Staff Coordinator** - Oversight & procurement  
✅ **Asset Lifecycle Tracking** - From allocation to return  
✅ **Financial Tracking** - Receipt upload & budget monitoring  
✅ **PDF Reports** - Comprehensive report generation  
✅ **Role-Based Interfaces** - NO shared interfaces  

Each role sees **only their relevant interface** with appropriate permissions and functionality!

---

**Status**: ✅ PRODUCTION READY - All Role-Based Interfaces Complete
