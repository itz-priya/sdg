
  # CAMPUSFIN Portal Development

  This is a code bundle for CAMPUSFIN Portal Development. The original project is available at https://www.figma.com/design/ZVsXQJtuq8cPPwbSp1f8lB/CAMPUSFIN-Portal-Development.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  